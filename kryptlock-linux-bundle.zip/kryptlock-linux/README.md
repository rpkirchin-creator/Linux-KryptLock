# KryptLock — Linux Multi-Format Compression & Encrypted Archive Utility

KryptLock packs, locks, verifies, and extracts **`.klock` (AES-256-GCM)**, **`.rar` (RAR & UnRAR with or without passwords)**, **`.7z` (with or without AES-256 + header encryption)**, **`.zip` (with or without AES-256 / ZipCrypto)**, **`.gz` / `.tar.gz` / `.tgz`**, **`.bz2` / `.tar.bz2`**, **`.xz` / `.tar.xz`**, and **`.tar`** archives.

---

## Requirements

### Native Linux Desktop & CLI
- **Operating System**: Any modern Linux distribution (Ubuntu 22.04+, Debian 12+, Linux Mint 21+, Fedora 39+, Arch Linux, Manjaro, Pop!_OS)
- **Python**: Python 3.9 or newer
- **Display Server (GUI)**: Wayland or X11 (GTK4/Libadwaita or Tkinter fallback)
- **Email Client Integration (Optional)**: `xdg-utils` (`xdg-email`) or `thunderbird` for attaching archives directly to an email draft

### Web Workbench (Optional Browser Sandbox)
- **Node.js & npm**: Node.js `v20.20.2`, `npm` `10.8.2`, `x86_64` (Rollup-based Vite 6 toolchain)
- **Browser**: Chromium, Firefox, GNOME Web, or Edge with WebAssembly + Web Crypto API (`window.crypto.subtle`)

---

## Dependencies

### Linux System & Python Dependencies
| Dependency | Debian / Ubuntu Package | Purpose |
| :--- | :--- | :--- |
| Python Cryptography | `python3-cryptography` | `AESGCM`, `PBKDF2HMAC`, SHA-256 for `.klock` |
| GTK4 + Libadwaita | `python3-gi gir1.2-gtk-4.0 gir1.2-adw-1` | Native GNOME/Adwaita desktop GUI |
| Tkinter (Fallback) | `python3-tk` | Automatic fallback GUI if GTK4 is unavailable |
| 7-Zip | `p7zip-full` (or `7zip`) | Create & extract `.7z` and AES-256 `.zip` archives |
| RAR / UnRAR | `rar unrar` (or `unar`) | Create `.rar` and extract/unrar `.rar` (with/without passwords) |
| XDG Email / Desktop | `xdg-utils` | `xdg-email --attach` & desktop/MIME integration |
| Compression Codecs | Built into Python 3 stdlib | `zipfile`, `tarfile`, `gzip`, `bz2`, `lzma`, `zlib` |

Install system dependencies by distro:

- **Ubuntu / Debian / Linux Mint / Pop!_OS**
  ```bash
  sudo apt update
  sudo apt install -y python3 python3-cryptography python3-gi gir1.2-gtk-4.0 gir1.2-adw-1 p7zip-full unrar rar xdg-utils
  ```

- **Fedora / RHEL**
  ```bash
  sudo dnf install -y python3 python3-cryptography python3-gobject gtk4 libadwaita p7zip p7zip-plugins unrar xdg-utils
  ```

- **Arch Linux / Manjaro**
  ```bash
  sudo pacman -S --needed python python-cryptography python-gobject gtk4 libadwaita 7zip unrar xdg-utils
  ```

### Web Workbench Dependencies (in `package.json`)
- `7z-wasm` — Emscripten WebAssembly 7-Zip (`.7z`, `.tar.gz`, `.tar.bz2`, `.tar.xz`, `.tar`, `.xz`, etc.)
- `node-unrar-js` — Official UnRAR WebAssembly (`.rar` extraction with and without passwords)
- `@zip.js/zip.js` — Pure-JS `.zip` creation & extraction (AES-256, ZipCrypto, and unencrypted)
- `fflate` — Zlib Deflate, Gzip, and ZIP archive packaging
- `compressjs` — Pure-JS Bzip2 codec
- `lzma` — Pure-JS LZMA1 codec

---

## Installation

### Option A: Ubuntu / Debian .deb Package (Recommended)
Download `kryptlock_1.0.0_all.deb` from the **Linux Native App** tab and run:

    cd ~/Downloads && sudo apt update && sudo apt install -y ./kryptlock_1.0.0_all.deb

Check detected backends and launch:

    kryptlock formats && kryptlock-gui

### Option B: Portable .zip Bundle (All Linux Distros)
Download `kryptlock-linux-bundle.zip` and run this single line (do not type `bash` by itself on line 1):

    cd ~/Downloads && unzip -o kryptlock-linux-bundle.zip && bash kryptlock-linux/install.sh

---

## How to Use the App

### 1. Native Linux CLI (`kryptlock`)
```bash
# Create RAR with a password (and encrypted headers) or without a password
kryptlock pack backup.rar ./documents --encrypt-headers --write-checksum
kryptlock pack backup-open.rar ./documents --no-password

# Extract (UnRAR) a password-protected or unencrypted .rar archive
kryptlock unpack backup.rar -o ./restored
kryptlock unpack backup-open.rar -o ./restored --no-password

# Create & extract 7-Zip (.7z) with or without password
kryptlock pack vault.7z ./secrets --encrypt-headers --write-checksum
kryptlock pack public.7z ./assets --no-password
kryptlock unpack vault.7z -o ./restored

# Create & extract ZIP (.zip) with AES-256 password or unencrypted
kryptlock pack release.zip ./dist
kryptlock pack release-open.zip ./dist --no-password

# Gzip, Bzip2, and XZ tarballs
kryptlock pack logs.tar.gz ./var-log
kryptlock pack logs.tar.bz2 ./var-log
kryptlock pack logs.tar.xz ./var-log

# KryptLock (.klock) AES-256-GCM vault with SHA-256 verification & email attachment
kryptlock lock secrets.klock ./documents --algo lzma --write-checksum --email colleague@example.com
kryptlock email vault.7z --to colleague@example.com
```

### 2. Native Linux Desktop GUI (`kryptlock-gui`)
1. Launch **KryptLock** from your application menu or run `kryptlock-gui`.
2. In **Pack & Lock**, add files or folders, choose a format (`klock`, `rar`, `7z`, `zip`, `tar.gz`, `tar.bz2`, `tar.xz`, `gz`), optionally set a password (or leave blank for unencrypted `.rar`/`.7z`/`.zip`), and click **Create Archive**.
3. Click **Email Archive** to open your Linux mail app (`xdg-email` / Thunderbird) with the archive and `.sha256` sidecar attached.
4. In **Unpack & Verify**, select any `.klock`, `.rar`, `.7z`, `.zip`, `.gz`, `.bz2`, or `.xz` file, enter a password if locked, and extract.

### 3. Browser Workbench
1. In **Pack & Lock**, drop multiple files or folders, pick `.klock`, `.7z`, `.zip`, `.gz / .tar.gz`, `.bz2 / .tar.bz2`, or `.xz / .tar.xz`, and enter an optional password (required for `.klock`).
2. In **Unpack & Extract**, drop any `.klock`, `.rar`, `.7z`, `.zip`, `.gz`, `.bz2`, `.xz`, or `.tar` archive (with or without a password) to verify SHA-256 checksums, preview files, and extract locally.
