#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${HOME}/.local/share/kryptlock"
BIN_DIR="${HOME}/.local/bin"
DESKTOP_DIR="${HOME}/.local/share/applications"
MIME_DIR="${HOME}/.local/share/mime/packages"
ICON_DIR="${HOME}/.local/share/icons/hicolor/scalable/apps"
NAUTILUS_DIR="${HOME}/.local/share/nautilus/scripts"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Error: python3 is required. Install it first: sudo apt install -y python3" >&2
  exit 1
fi

echo "Installing KryptLock from ${SCRIPT_DIR} into ${APP_DIR}..."
mkdir -p "${APP_DIR}" "${BIN_DIR}" "${DESKTOP_DIR}" "${MIME_DIR}" "${ICON_DIR}" "${NAUTILUS_DIR}"

cp "${SCRIPT_DIR}/kryptlock.py" "${SCRIPT_DIR}/kryptlock_gui.py" "${APP_DIR}/"
chmod +x "${APP_DIR}/kryptlock.py" "${APP_DIR}/kryptlock_gui.py"

cat > "${BIN_DIR}/kryptlock" <<EOF
#!/usr/bin/env bash
PYTHONPATH="${APP_DIR}" exec python3 "${APP_DIR}/kryptlock.py" "\$@"
EOF
chmod +x "${BIN_DIR}/kryptlock"

cat > "${BIN_DIR}/kryptlock-gui" <<EOF
#!/usr/bin/env bash
PYTHONPATH="${APP_DIR}" exec python3 "${APP_DIR}/kryptlock_gui.py" "\$@"
EOF
chmod +x "${BIN_DIR}/kryptlock-gui"

if [ -f "${SCRIPT_DIR}/kryptlock.svg" ]; then
  cp "${SCRIPT_DIR}/kryptlock.svg" "${ICON_DIR}/kryptlock.svg"
fi
if [ -f "${SCRIPT_DIR}/krypt.png" ]; then
  cp "${SCRIPT_DIR}/krypt.png" "${APP_DIR}/krypt.png"
fi

# Write desktop entry with an absolute Exec path so GNOME/Ubuntu launches it reliably
sed "s|^Exec=.*|Exec=${BIN_DIR}/kryptlock-gui %f|" "${SCRIPT_DIR}/kryptlock.desktop" > "${DESKTOP_DIR}/kryptlock.desktop"
cp "${SCRIPT_DIR}/kryptlock-mime.xml" "${MIME_DIR}/kryptlock-mime.xml"
cp "${SCRIPT_DIR}/nautilus-script.sh" "${NAUTILUS_DIR}/Lock with KryptLock"
chmod +x "${NAUTILUS_DIR}/Lock with KryptLock"
cat > "${NAUTILUS_DIR}/Unpack with KryptLock" <<EOF
#!/usr/bin/env bash
set -euo pipefail
if [ "\$#" -gt 0 ]; then
  exec "${BIN_DIR}/kryptlock-gui" "\$1"
else
  exec "${BIN_DIR}/kryptlock-gui"
fi
EOF
chmod +x "${NAUTILUS_DIR}/Unpack with KryptLock"

if command -v update-mime-database >/dev/null 2>&1; then
  update-mime-database "${HOME}/.local/share/mime" || true
fi
if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "${DESKTOP_DIR}" || true
fi
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -q -t -f "${HOME}/.local/share/icons/hicolor" || true
fi

# Ensure ~/.local/bin is in PATH for future terminals
PATH_LINE='export PATH="$HOME/.local/bin:$PATH"'
for rc in "${HOME}/.bashrc" "${HOME}/.profile"; do
  if [ -f "${rc}" ] && ! grep -q '\.local/bin' "${rc}"; then
    printf '\n# Added by KryptLock installer\n%s\n' "${PATH_LINE}" >> "${rc}"
  fi
done

echo ""
echo "Checking Python & archive dependencies..."
MISSING_APT=()
python3 -c "import cryptography" >/dev/null 2>&1 || MISSING_APT+=("python3-cryptography")
python3 -c "import gi; gi.require_version('Gtk', '4.0'); gi.require_version('Adw', '1')" >/dev/null 2>&1 || MISSING_APT+=("python3-gi" "gir1.2-gtk-4.0" "gir1.2-adw-1")
command -v 7z >/dev/null 2>&1 || command -v 7zz >/dev/null 2>&1 || MISSING_APT+=("p7zip-full")
command -v unrar >/dev/null 2>&1 || command -v unar >/dev/null 2>&1 || MISSING_APT+=("unrar")

if [ ${#MISSING_APT[@]} -gt 0 ]; then
  echo "Notice: Optional or required Ubuntu packages not detected: ${MISSING_APT[*]}"
  echo "Run: sudo apt update && sudo apt install -y ${MISSING_APT[*]} xdg-utils"
fi

echo ""
echo "KryptLock installed successfully!"
echo "CLI binary: ${BIN_DIR}/kryptlock"
echo "GUI binary: ${BIN_DIR}/kryptlock-gui"
echo ""
"${BIN_DIR}/kryptlock" formats || true
echo ""
echo "Open a new terminal (or run: export PATH=\"\$HOME/.local/bin:\$PATH\") and launch with: kryptlock-gui"
