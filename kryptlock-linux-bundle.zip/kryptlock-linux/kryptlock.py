#!/usr/bin/env python3
"""
KryptLock - Native Linux Multi-Format Compression & Encrypted Archive Utility
Supports:
  - .klock (KLOCK001: AES-256-GCM + Deflate/Gzip/Bzip2/LZMA/Store + SHA-256)
  - .rar   (Create via 'rar', extract/unrar via 'unrar' / 'rar' / '7z' / 'unar' with & without passwords)
  - .7z    (Create & extract via '7z' / '7zz' with & without AES-256 + header encryption)
  - .zip   (Create & extract with & without AES-256 / ZipCrypto passwords)
  - .gz / .tar.gz / .tgz, .bz2 / .tar.bz2, .xz / .tar.xz, .tar
"""

import argparse
import bz2
import getpass
import gzip
import hashlib
import json
import lzma
import math
import os
import re
import secrets
import shutil
import struct
import subprocess
import sys
import tarfile
import time
import urllib.parse
import zipfile
import zlib
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False

MAGIC = b"KLOCK001"
HEADER_LENGTH = 41  # 8 magic + 1 flag + 4 iterations + 16 salt + 12 iv
DEFAULT_ITERATIONS = 600_000

ALGO_TO_FLAG: Dict[str, int] = {
    "deflate": 0x01,
    "store": 0x02,
    "gzip": 0x03,
    "bzip2": 0x04,
    "lzma": 0x05,
}
FLAG_TO_ALGO: Dict[int, str] = {v: k for k, v in ALGO_TO_FLAG.items()}

SUPPORTED_PACK_FORMATS = [
    "klock",
    "rar",
    "7z",
    "zip",
    "tar.gz",
    "gz",
    "tar.bz2",
    "bz2",
    "tar.xz",
    "xz",
    "tar",
]


class IntegrityError(Exception):
    """Raised when an archive or extracted file fails SHA-256 verification."""


def require_cryptography() -> None:
    if not HAS_CRYPTOGRAPHY:
        raise RuntimeError(
            "Python 'cryptography' package is required for .klock AES-256-GCM archives.\n"
            "Install on Ubuntu/Debian: sudo apt install python3-cryptography\n"
            "Install on Fedora:        sudo dnf install python3-cryptography\n"
            "Install on Arch:          sudo pacman -S python-cryptography"
        )


def find_7z_binary() -> Optional[str]:
    return shutil.which("7z") or shutil.which("7zz") or shutil.which("7za")


def detect_available_backends() -> dict:
    return {
        "klock_aes_gcm": HAS_CRYPTOGRAPHY,
        "rar_create": shutil.which("rar"),
        "rar_extract": shutil.which("unrar") or shutil.which("rar") or find_7z_binary() or shutil.which("unar"),
        "7z": find_7z_binary(),
        "zip_cli": shutil.which("zip"),
        "unzip_cli": shutil.which("unzip"),
        "python_stdlib": "zipfile, tarfile, gzip, bz2, lzma, zlib",
    }


def evaluate_password_strength(password: str, has_keyfile: bool = False) -> dict:
    if not password and not has_keyfile:
        return {
            "bits": 0,
            "score": 0,
            "label": "Empty",
            "hints": ["Enter a password (12+ characters recommended)."],
        }

    charset = 0
    has_lower = bool(re.search(r"[a-z]", password))
    has_upper = bool(re.search(r"[A-Z]", password))
    has_digit = bool(re.search(r"[0-9]", password))
    has_symbol = bool(re.search(r"[^a-zA-Z0-9]", password))

    if has_lower:
        charset += 26
    if has_upper:
        charset += 26
    if has_digit:
        charset += 10
    if has_symbol:
        charset += 32

    base_bits = len(password) * (math.log2(charset) if charset > 0 else 0.0)
    bits = round(base_bits + (128 if has_keyfile else 0))

    hints: List[str] = []
    if len(password) < 12:
        hints.append("Use at least 12 characters")
    if not has_upper:
        hints.append("Add uppercase letters")
    if not has_digit:
        hints.append("Add digits")
    if not has_symbol:
        hints.append("Add symbols or hyphens")

    if bits >= 96:
        return {"bits": bits, "score": 4, "label": "Very Strong", "hints": []}
    if bits >= 64:
        return {"bits": bits, "score": 3, "label": "Strong", "hints": hints[:1]}
    if bits >= 40:
        return {"bits": bits, "score": 2, "label": "Moderate", "hints": hints[:2]}
    return {"bits": bits, "score": 1, "label": "Weak", "hints": hints}


def normalize_expected_checksum(raw_value: str) -> str:
    candidate = raw_value.strip()
    path = Path(candidate)
    if path.is_file():
        candidate = path.read_text(encoding="utf-8", errors="replace").strip()
    match = re.search(r"([a-fA-F0-9]{64})", candidate)
    if not match:
        raise ValueError("Expected checksum must be a 64-character SHA-256 hex digest or .sha256 file.")
    return match.group(1).lower()


def compute_file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def build_secret_material(passphrase: str, keyfile_path: Optional[Path] = None) -> bytes:
    if keyfile_path is not None:
        keyfile_bytes = keyfile_path.read_bytes()
        if len(keyfile_bytes) > 0:
            digest = hashlib.sha256(keyfile_bytes).hexdigest()
            return f"{passphrase}:{digest}".encode("utf-8")
    return passphrase.encode("utf-8")


def derive_aes_key(secret: bytes, salt: bytes, iterations: int) -> bytes:
    require_cryptography()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=iterations,
    )
    return kdf.derive(secret)


def compress_payload(data: bytes, algorithm: str, level: int = 6) -> bytes:
    lvl = max(1, min(9, level))
    if algorithm == "store":
        return data
    if algorithm == "deflate":
        return zlib.compress(data, level=lvl)
    if algorithm == "gzip":
        return gzip.compress(data, compresslevel=lvl)
    if algorithm == "bzip2":
        return bz2.compress(data, compresslevel=lvl)
    if algorithm == "lzma":
        return lzma.compress(data, format=lzma.FORMAT_ALONE, preset=lvl)
    raise ValueError(f"Unsupported compression algorithm: {algorithm}")


def decompress_payload(data: bytes, algorithm: str) -> bytes:
    if algorithm == "store":
        return data
    if algorithm == "deflate":
        return zlib.decompress(data)
    if algorithm == "gzip":
        return gzip.decompress(data)
    if algorithm == "bzip2":
        return bz2.decompress(data)
    if algorithm == "lzma":
        return lzma.decompress(data, format=lzma.FORMAT_ALONE)
    raise ValueError(f"Unsupported compression algorithm: {algorithm}")


def collect_input_files(paths: List[Path]) -> List[Tuple[Path, str]]:
    collected: List[Tuple[Path, str]] = []
    for raw_path in paths:
        target = raw_path.resolve()
        if not target.exists():
            raise FileNotFoundError(f"Path not found: {raw_path}")
        if target.is_file():
            collected.append((target, target.name))
        elif target.is_dir():
            base_parent = target.parent
            for root, _, filenames in os.walk(target):
                for fname in sorted(filenames):
                    fpath = Path(root) / fname
                    rel = fpath.relative_to(base_parent).as_posix()
                    collected.append((fpath, rel))
    return collected


def detect_archive_format(archive_path: Path) -> str:
    head = archive_path.read_bytes()[:512]
    lower = archive_path.name.lower()
    if head.startswith(MAGIC):
        return "klock"
    if head.startswith(b"Rar!\x1a\x07"):
        return "rar"
    if head.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7z"
    if head.startswith((b"PK\x03\x04", b"PK\x05\x06")):
        return "zip"
    if head.startswith(b"\x1f\x8b"):
        return "tar.gz" if lower.endswith((".tar.gz", ".tgz")) else "gz"
    if head.startswith(b"BZh"):
        return "tar.bz2" if lower.endswith((".tar.bz2", ".tbz2", ".tbz")) else "bz2"
    if head.startswith(b"\xfd7zXZ\x00"):
        return "tar.xz" if lower.endswith((".tar.xz", ".txz")) else "xz"
    if len(head) >= 263 and head[257:262] == b"ustar":
        return "tar"

    for ext, fmt in [
        (".klock", "klock"),
        (".rar", "rar"),
        (".7z", "7z"),
        (".zip", "zip"),
        (".tar.gz", "tar.gz"),
        (".tgz", "tar.gz"),
        (".gz", "gz"),
        (".tar.bz2", "tar.bz2"),
        (".tbz2", "tar.bz2"),
        (".bz2", "bz2"),
        (".tar.xz", "tar.xz"),
        (".txz", "tar.xz"),
        (".xz", "xz"),
        (".tar", "tar"),
    ]:
        if lower.endswith(ext):
            return fmt
    raise ValueError(f"Unrecognized archive format: {archive_path.name}")


def format_from_output_name(output_path: Path, explicit_format: Optional[str] = None) -> str:
    if explicit_format:
        return explicit_format
    lower = output_path.name.lower()
    for ext, fmt in [
        (".klock", "klock"),
        (".rar", "rar"),
        (".7z", "7z"),
        (".zip", "zip"),
        (".tar.gz", "tar.gz"),
        (".tgz", "tar.gz"),
        (".gz", "gz"),
        (".tar.bz2", "tar.bz2"),
        (".tbz2", "tar.bz2"),
        (".bz2", "bz2"),
        (".tar.xz", "tar.xz"),
        (".txz", "tar.xz"),
        (".xz", "xz"),
        (".tar", "tar"),
    ]:
        if lower.endswith(ext):
            return fmt
    return "klock"


def encrypt_archive(
    input_paths: List[Path],
    output_path: Path,
    passphrase: str,
    keyfile_path: Optional[Path] = None,
    algorithm: str = "deflate",
    level: int = 6,
    iterations: int = DEFAULT_ITERATIONS,
    write_checksum_file: bool = False,
) -> dict:
    require_cryptography()
    if algorithm not in ALGO_TO_FLAG:
        raise ValueError(f"Unsupported algorithm '{algorithm}'. Choose from: {', '.join(ALGO_TO_FLAG)}")

    files = collect_input_files(input_paths)
    if not files:
        raise ValueError("No files found to lock.")

    entries_meta = []
    chunks: List[bytes] = []

    for abs_path, rel_path in files:
        data = abs_path.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        stat = abs_path.stat()
        entries_meta.append(
            {
                "path": rel_path,
                "size": len(data),
                "mtime": int(stat.st_mtime * 1000),
                "sha256": sha,
            }
        )
        chunks.append(data)

    raw_payload = b"".join(chunks)
    payload_sha256 = hashlib.sha256(raw_payload).hexdigest()

    manifest = {
        "version": 2,
        "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "compressionAlgorithm": algorithm,
        "payloadSha256": payload_sha256,
        "entries": entries_meta,
    }
    manifest_bytes = json.dumps(manifest, separators=(",", ":")).encode("utf-8")
    inner_container = struct.pack(">I", len(manifest_bytes)) + manifest_bytes + raw_payload

    flag = ALGO_TO_FLAG[algorithm]
    compressed_payload = compress_payload(inner_container, algorithm, level=level)

    salt = secrets.token_bytes(16)
    iv = secrets.token_bytes(12)
    header = MAGIC + bytes([flag]) + struct.pack(">I", iterations) + salt + iv

    secret = build_secret_material(passphrase, keyfile_path)
    aes_key = derive_aes_key(secret, salt, iterations)
    ciphertext = AESGCM(aes_key).encrypt(iv, compressed_payload, header)

    archive_bytes = header + ciphertext
    archive_sha256 = hashlib.sha256(archive_bytes).hexdigest()
    output_path.write_bytes(archive_bytes)

    checksum_path: Optional[Path] = None
    if write_checksum_file:
        checksum_path = Path(f"{output_path}.sha256")
        checksum_path.write_text(f"{archive_sha256}  {output_path.name}\n", encoding="utf-8")

    return {
        "output": str(output_path),
        "format": "klock",
        "algorithm": algorithm,
        "entries": len(entries_meta),
        "uncompressed": len(inner_container),
        "compressed": len(compressed_payload),
        "archive_size": len(archive_bytes),
        "archive_sha256": archive_sha256,
        "payload_sha256": payload_sha256,
        "checksum_file": str(checksum_path) if checksum_path else None,
    }


def inspect_archive(archive_path: Path) -> dict:
    raw = archive_path.read_bytes()
    if len(raw) < HEADER_LENGTH + 16:
        raise ValueError("File is too small to be a valid .klock archive.")
    magic = raw[:8]
    if magic != MAGIC:
        raise ValueError(f"Invalid magic header: {magic!r}")
    flag = raw[8]
    if flag not in FLAG_TO_ALGO:
        raise ValueError(f"Unsupported compression flag: 0x{flag:02x}")
    (iterations,) = struct.unpack(">I", raw[9:13])
    salt = raw[13:29]
    iv = raw[29:41]
    return {
        "magic": magic.decode("ascii"),
        "format": "klock",
        "compression": FLAG_TO_ALGO[flag],
        "iterations": iterations,
        "salt_hex": salt.hex(),
        "iv_hex": iv.hex(),
        "total_bytes": len(raw),
        "ciphertext_bytes": len(raw) - HEADER_LENGTH,
        "archive_sha256": hashlib.sha256(raw).hexdigest(),
    }


def inspect_any_archive(archive_path: Path) -> dict:
    fmt = detect_archive_format(archive_path)
    if fmt == "klock":
        return inspect_archive(archive_path)
    return {
        "magic": fmt.upper(),
        "format": fmt,
        "compression": fmt,
        "total_bytes": archive_path.stat().st_size,
        "archive_sha256": compute_file_sha256(archive_path),
    }


def decrypt_archive_to_memory(
    archive_path: Path,
    passphrase: str,
    keyfile_path: Optional[Path] = None,
    expected_checksum: Optional[str] = None,
) -> Tuple[dict, List[Tuple[dict, bytes, bool]], dict]:
    require_cryptography()
    raw = archive_path.read_bytes()
    info = inspect_archive(archive_path)

    if expected_checksum:
        expected_hex = normalize_expected_checksum(expected_checksum)
        if info["archive_sha256"] != expected_hex:
            raise IntegrityError(
                f"Archive SHA-256 mismatch! Expected {expected_hex}, computed {info['archive_sha256']}."
            )

    header = raw[:HEADER_LENGTH]
    salt = raw[13:29]
    iv = raw[29:41]
    ciphertext = raw[HEADER_LENGTH:]

    secret = build_secret_material(passphrase, keyfile_path)
    aes_key = derive_aes_key(secret, salt, info["iterations"])
    try:
        payload = AESGCM(aes_key).decrypt(iv, ciphertext, header)
    except Exception as exc:
        raise ValueError(
            "Decryption failed: incorrect password, missing keyfile, or corrupted archive."
        ) from exc

    inner_container = decompress_payload(payload, info["compression"])
    (manifest_len,) = struct.unpack(">I", inner_container[:4])
    manifest = json.loads(inner_container[4 : 4 + manifest_len].decode("utf-8"))

    raw_payload = inner_container[4 + manifest_len :]
    computed_payload_sha = hashlib.sha256(raw_payload).hexdigest()
    stored_payload_sha = manifest.get("payloadSha256")
    container_ok = stored_payload_sha is None or stored_payload_sha == computed_payload_sha

    cursor = 0
    extracted = []
    failed_paths: List[str] = []
    for entry in manifest["entries"]:
        size = entry["size"]
        data = raw_payload[cursor : cursor + size]
        cursor += size
        actual_sha = hashlib.sha256(data).hexdigest()
        ok = actual_sha == entry["sha256"]
        if not ok:
            failed_paths.append(entry["path"])
        extracted.append((entry, data, ok))

    integrity = {
        "archive_sha256": info["archive_sha256"],
        "container_ok": container_ok,
        "all_files_ok": container_ok and len(failed_paths) == 0,
        "failed_paths": failed_paths,
    }
    return manifest, extracted, integrity


def safe_extract_path(output_dir: Path, rel_path: str) -> Path:
    dest = (output_dir / rel_path).resolve()
    root = output_dir.resolve()
    if root not in dest.parents and dest != root:
        raise ValueError(f"Blocked unsafe archive path traversal: {rel_path}")
    return dest


def unlock_archive(
    archive_path: Path,
    output_dir: Path,
    passphrase: str,
    keyfile_path: Optional[Path] = None,
    expected_checksum: Optional[str] = None,
) -> Tuple[List[Tuple[str, int, bool]], dict]:
    _, extracted, integrity = decrypt_archive_to_memory(
        archive_path,
        passphrase,
        keyfile_path=keyfile_path,
        expected_checksum=expected_checksum,
    )
    if not integrity["all_files_ok"]:
        raise IntegrityError(
            f"Integrity check failed for: {', '.join(integrity['failed_paths']) or 'inner container'}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    results = []
    for entry, data, verified in extracted:
        dest = safe_extract_path(output_dir, entry["path"])
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        results.append((entry["path"], entry["size"], verified))
    return results, integrity


def pack_archive(
    input_paths: List[Path],
    output_path: Path,
    fmt: Optional[str] = None,
    passphrase: Optional[str] = None,
    keyfile_path: Optional[Path] = None,
    algorithm: str = "deflate",
    level: int = 6,
    iterations: int = DEFAULT_ITERATIONS,
    encrypt_headers: bool = True,
    zip_crypto: bool = False,
    write_checksum_file: bool = False,
) -> dict:
    resolved_fmt = format_from_output_name(output_path, fmt)
    if resolved_fmt == "klock":
        if not passphrase and keyfile_path is None:
            raise ValueError("A password or keyfile is required for .klock archives.")
        return encrypt_archive(
            input_paths,
            output_path,
            passphrase or "",
            keyfile_path=keyfile_path,
            algorithm=algorithm,
            level=level,
            iterations=iterations,
            write_checksum_file=write_checksum_file,
        )

    files = collect_input_files(input_paths)
    if not files:
        raise ValueError("No files found to pack.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    out_abs = output_path.resolve()
    if out_abs.exists():
        out_abs.unlink()

    if resolved_fmt == "rar":
        rar_bin = shutil.which("rar")
        if not rar_bin:
            raise RuntimeError(
                "Creating .rar archives requires the Linux 'rar' CLI binary.\n"
                "Install it on Ubuntu/Debian: sudo apt install rar\n"
                "Or use .7z / .zip / .klock which work out of the box."
            )
        rar_lvl = min(5, max(0, round((level / 9) * 5)))
        cmd = [rar_bin, "a", "-r", "-ep1", f"-m{rar_lvl}"]
        if passphrase:
            cmd.append(f"-hp{passphrase}" if encrypt_headers else f"-p{passphrase}")
        cmd.append(str(out_abs))
        cmd.extend(str(p.resolve()) for p in input_paths)
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "rar failed.")

    elif resolved_fmt == "7z":
        sz_bin = find_7z_binary()
        if not sz_bin:
            raise RuntimeError(
                "Creating .7z archives requires 7-Zip ('p7zip-full' or '7zip').\n"
                "Install on Ubuntu/Debian: sudo apt install p7zip-full\n"
                "Install on Fedora:        sudo dnf install p7zip p7zip-plugins\n"
                "Install on Arch:          sudo pacman -S 7zip"
            )
        cmd = [sz_bin, "a", "-t7z", f"-mx={max(1, min(9, level))}"]
        if passphrase:
            cmd.append(f"-p{passphrase}")
            if encrypt_headers:
                cmd.append("-mhe=on")
        cmd.append(str(out_abs))
        cmd.extend(str(p.resolve()) for p in input_paths)
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "7z failed.")

    elif resolved_fmt == "zip":
        if passphrase:
            sz_bin = find_7z_binary()
            zip_bin = shutil.which("zip")
            if sz_bin:
                method = "ZipCrypto" if zip_crypto else "AES256"
                cmd = [sz_bin, "a", "-tzip", f"-mx={max(1, min(9, level))}", f"-mem={method}", f"-p{passphrase}", str(out_abs)]
                cmd.extend(str(p.resolve()) for p in input_paths)
                proc = subprocess.run(cmd, capture_output=True, text=True)
                if proc.returncode != 0:
                    raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "7z zip creation failed.")
            elif zip_bin:
                cmd = [zip_bin, "-r", "-P", passphrase, str(out_abs)]
                cmd.extend(str(p) for p in input_paths)
                proc = subprocess.run(cmd, capture_output=True, text=True)
                if proc.returncode != 0:
                    raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "zip failed.")
            else:
                raise RuntimeError("Password-protected .zip creation requires '7z' (p7zip-full) or 'zip'.")
        else:
            with zipfile.ZipFile(out_abs, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=max(1, min(9, level))) as zf:
                for abs_path, rel_path in files:
                    zf.write(abs_path, arcname=rel_path)

    elif resolved_fmt in ("gz", "bz2", "xz"):
        if len(files) > 1:
            raise ValueError(f"Single-stream .{resolved_fmt} holds 1 file. Use .tar.{resolved_fmt} for multiple files.")
        raw_bytes = files[0][0].read_bytes()
        if resolved_fmt == "gz":
            out_abs.write_bytes(gzip.compress(raw_bytes, compresslevel=max(1, min(9, level))))
        elif resolved_fmt == "bz2":
            out_abs.write_bytes(bz2.compress(raw_bytes, compresslevel=max(1, min(9, level))))
        else:
            out_abs.write_bytes(lzma.compress(raw_bytes, preset=max(1, min(9, level))))

    elif resolved_fmt in ("tar.gz", "tar.bz2", "tar.xz", "tar"):
        mode_map = {"tar": "w", "tar.gz": "w:gz", "tar.bz2": "w:bz2", "tar.xz": "w:xz"}
        with tarfile.open(out_abs, mode=mode_map[resolved_fmt]) as tf:
            for abs_path, rel_path in files:
                tf.add(abs_path, arcname=rel_path)
    else:
        raise ValueError(f"Unsupported output format: {resolved_fmt}")

    archive_sha256 = compute_file_sha256(out_abs)
    checksum_path: Optional[Path] = None
    if write_checksum_file:
        checksum_path = Path(f"{out_abs}.sha256")
        checksum_path.write_text(f"{archive_sha256}  {out_abs.name}\n", encoding="utf-8")

    return {
        "output": str(out_abs),
        "format": resolved_fmt,
        "algorithm": resolved_fmt,
        "entries": len(files),
        "encrypted": bool(passphrase),
        "archive_size": out_abs.stat().st_size,
        "archive_sha256": archive_sha256,
        "checksum_file": str(checksum_path) if checksum_path else None,
    }


def unpack_archive(
    archive_path: Path,
    output_dir: Path,
    passphrase: Optional[str] = None,
    keyfile_path: Optional[Path] = None,
    expected_checksum: Optional[str] = None,
) -> Tuple[List[Tuple[str, int, bool]], dict]:
    if not archive_path.is_file():
        raise FileNotFoundError(f"Archive not found: {archive_path}")

    actual_sha = compute_file_sha256(archive_path)
    if expected_checksum:
        expected_hex = normalize_expected_checksum(expected_checksum)
        if actual_sha != expected_hex:
            raise IntegrityError(f"Archive SHA-256 mismatch! Expected {expected_hex}, computed {actual_sha}.")

    fmt = detect_archive_format(archive_path)
    if fmt == "klock":
        return unlock_archive(
            archive_path,
            output_dir,
            passphrase or "",
            keyfile_path=keyfile_path,
            expected_checksum=expected_checksum,
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    out_abs = output_dir.resolve()
    arc_abs = archive_path.resolve()

    if fmt == "rar":
        unrar_bin = shutil.which("unrar") or shutil.which("rar")
        sz_bin = find_7z_binary()
        unar_bin = shutil.which("unar")
        if unrar_bin:
            pw_flag = f"-p{passphrase}" if passphrase else "-p-"
            proc = subprocess.run([unrar_bin, "x", "-o+", pw_flag, str(arc_abs), f"{out_abs}/"], capture_output=True, text=True)
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "unrar failed (wrong or missing password).")
        elif sz_bin:
            pw_flag = f"-p{passphrase}" if passphrase else "-p-"
            proc = subprocess.run([sz_bin, "x", "-y", pw_flag, f"-o{out_abs}", str(arc_abs)], capture_output=True, text=True)
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "7z RAR extraction failed.")
        elif unar_bin:
            cmd = [unar_bin, "-force-overwrite", "-output-directory", str(out_abs)]
            if passphrase:
                cmd.extend(["-password", passphrase])
            cmd.append(str(arc_abs))
            proc = subprocess.run(cmd, capture_output=True, text=True)
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "unar failed.")
        else:
            raise RuntimeError("Extracting .rar requires 'unrar', 'rar', 'unar', or '7z' (with RAR plugin).")

    elif fmt == "7z":
        sz_bin = find_7z_binary()
        if not sz_bin:
            raise RuntimeError("Extracting .7z requires '7z' (install p7zip-full or 7zip).")
        pw_flag = f"-p{passphrase}" if passphrase else "-p-"
        proc = subprocess.run([sz_bin, "x", "-y", pw_flag, f"-o{out_abs}", str(arc_abs)], capture_output=True, text=True)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "7z extraction failed.")

    elif fmt == "zip":
        extracted_with_python = False
        try:
            with zipfile.ZipFile(arc_abs, "r") as zf:
                pwd_bytes = passphrase.encode("utf-8") if passphrase else None
                for member in zf.infolist():
                    if member.is_dir():
                        continue
                    dest = safe_extract_path(out_abs, member.filename)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(member, mode="r", pwd=pwd_bytes) as src:
                        dest.write_bytes(src.read())
                extracted_with_python = True
        except NotImplementedError:
            extracted_with_python = False
        except RuntimeError as exc:
            if "encrypted" in str(exc).lower() or "password" in str(exc).lower():
                raise ValueError("ZIP password is missing or incorrect.") from exc
            extracted_with_python = False

        if not extracted_with_python:
            sz_bin = find_7z_binary()
            unzip_bin = shutil.which("unzip")
            if sz_bin:
                pw_flag = f"-p{passphrase}" if passphrase else "-p-"
                proc = subprocess.run([sz_bin, "x", "-y", pw_flag, f"-o{out_abs}", str(arc_abs)], capture_output=True, text=True)
                if proc.returncode != 0:
                    raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "ZIP extraction failed.")
            elif unzip_bin:
                cmd = [unzip_bin, "-o"]
                if passphrase:
                    cmd.extend(["-P", passphrase])
                cmd.extend([str(arc_abs), "-d", str(out_abs)])
                proc = subprocess.run(cmd, capture_output=True, text=True)
                if proc.returncode != 0:
                    raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "unzip failed.")
            else:
                raise RuntimeError("This ZIP uses AES encryption. Install 'p7zip-full' (7z) or 'unzip'.")

    elif fmt in ("tar", "tar.gz", "tar.bz2", "tar.xz"):
        with tarfile.open(arc_abs, mode="r:*") as tf:
            for member in tf.getmembers():
                if not member.isfile():
                    continue
                dest = safe_extract_path(out_abs, member.name)
                dest.parent.mkdir(parents=True, exist_ok=True)
                src = tf.extractfile(member)
                if src is not None:
                    dest.write_bytes(src.read())

    elif fmt in ("gz", "bz2", "xz"):
        stem = re.sub(r"\.(gz|gzip|bz2|xz)$", "", arc_abs.name, flags=re.IGNORECASE) or "extracted.bin"
        dest = safe_extract_path(out_abs, stem)
        raw_bytes = arc_abs.read_bytes()
        if fmt == "gz":
            dest.write_bytes(gzip.decompress(raw_bytes))
        elif fmt == "bz2":
            dest.write_bytes(bz2.decompress(raw_bytes))
        else:
            dest.write_bytes(lzma.decompress(raw_bytes))

    extracted_summary: List[Tuple[str, int, bool]] = []
    for root, _, filenames in os.walk(out_abs):
        for fname in sorted(filenames):
            fpath = Path(root) / fname
            extracted_summary.append((fpath.relative_to(out_abs).as_posix(), fpath.stat().st_size, True))
    return extracted_summary, {
        "archive_sha256": actual_sha,
        "format": fmt,
        "all_files_ok": True,
    }


def open_email_composer(
    archive_path: Path,
    recipient: str,
    subject: Optional[str] = None,
    include_checksum: bool = True,
) -> str:
    resolved = archive_path.resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"Archive not found: {archive_path}")

    info = inspect_any_archive(resolved)
    mail_subject = subject or f"Archive: {resolved.name}"
    body_lines = [
        f"Attached is the archive ({resolved.name}) created with KryptLock.",
        "",
        f"Format: {info['format']} ({info['compression']})",
        f"Size: {info['total_bytes']} bytes",
    ]
    if include_checksum:
        body_lines.append(f"SHA-256 Checksum: {info['archive_sha256']}")
    body_lines.extend(
        [
            "",
            "To unpack: open with KryptLock (kryptlock-gui) or run:",
            f"  kryptlock unpack {resolved.name} -o ./restored",
            "",
            "Note: If password-protected, the password will be shared separately.",
        ]
    )
    body = "\n".join(body_lines)

    sidecar = Path(f"{resolved}.sha256")
    xdg_email = shutil.which("xdg-email")
    if xdg_email:
        cmd = [xdg_email, "--subject", mail_subject, "--body", body, "--attach", str(resolved)]
        if include_checksum and sidecar.is_file():
            cmd.extend(["--attach", str(sidecar)])
        if recipient.strip():
            cmd.append(recipient.strip())
        subprocess.Popen(cmd)
        return "xdg-email"

    thunderbird = shutil.which("thunderbird")
    if thunderbird:
        attachments = [str(resolved)]
        if include_checksum and sidecar.is_file():
            attachments.append(str(sidecar))
        compose_arg = (
            f"to='{recipient.strip()}',subject='{mail_subject}',"
            f"body='{body}',attachment='{','.join(attachments)}'"
        )
        subprocess.Popen([thunderbird, "-compose", compose_arg])
        return "thunderbird"

    xdg_open = shutil.which("xdg-open")
    if xdg_open:
        mailto = (
            f"mailto:{urllib.parse.quote(recipient.strip())}"
            f"?subject={urllib.parse.quote(mail_subject)}"
            f"&body={urllib.parse.quote(body)}"
        )
        subprocess.Popen([xdg_open, mailto])
        return "mailto"

    raise RuntimeError(
        "No Linux email launcher found (install xdg-utils or thunderbird)."
    )


def prompt_passphrase(confirm: bool = False, allow_empty: bool = False) -> str:
    pw = getpass.getpass("Password (leave empty for none): " if allow_empty else "Password: ")
    if not pw and allow_empty:
        return ""
    if confirm:
        strength = evaluate_password_strength(pw)
        print(f"Password strength: {strength['label']} ({strength['bits']} bits)")
        if strength["hints"]:
            print(f"Tip: {'; '.join(strength['hints'])}")
        pw2 = getpass.getpass("Confirm password: ")
        if pw != pw2:
            raise ValueError("Passwords do not match.")
    return pw


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="kryptlock",
        description="KryptLock - Linux Multi-Format Compression (KLOCK/RAR/7z/ZIP/Gzip/Bzip2/XZ) & Encryption Tool",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_lock = sub.add_parser("lock", help="Compress and encrypt files/folders into a .klock archive")
    p_lock.add_argument("output", type=Path, help="Output .klock archive file")
    p_lock.add_argument("inputs", nargs="+", type=Path, help="Files or directories to lock")
    p_lock.add_argument("-a", "--algo", choices=list(ALGO_TO_FLAG.keys()), default="deflate")
    p_lock.add_argument("--level", type=int, default=6, choices=range(1, 10))
    p_lock.add_argument("--iterations", type=int, default=DEFAULT_ITERATIONS)
    p_lock.add_argument("--keyfile", type=Path, default=None)
    p_lock.add_argument("--write-checksum", action="store_true")
    p_lock.add_argument("--email", type=str, default=None)

    p_pack = sub.add_parser("pack", help="Pack files into .klock, .rar, .7z, .zip, .tar.gz/.gz, .tar.bz2/.bz2, or .tar.xz/.xz")
    p_pack.add_argument("output", type=Path, help="Output archive file (.rar, .7z, .zip, .tar.gz, .klock, ...)")
    p_pack.add_argument("inputs", nargs="+", type=Path, help="Files or directories to pack")
    p_pack.add_argument("-f", "--format", choices=SUPPORTED_PACK_FORMATS, default=None)
    p_pack.add_argument("-a", "--algo", choices=list(ALGO_TO_FLAG.keys()), default="deflate", help=".klock inner compression")
    p_pack.add_argument("--level", type=int, default=6, choices=range(1, 10))
    p_pack.add_argument("--no-password", action="store_true", help="Create unencrypted archive without password prompt")
    p_pack.add_argument("--encrypt-headers", action="store_true", help="Encrypt filenames/headers (.rar -hp / .7z -mhe)")
    p_pack.add_argument("--zip-crypto", action="store_true", help="Use legacy ZipCrypto instead of AES-256 for .zip")
    p_pack.add_argument("--keyfile", type=Path, default=None)
    p_pack.add_argument("--write-checksum", action="store_true")
    p_pack.add_argument("--email", type=str, default=None)

    p_unpack = sub.add_parser("unpack", help="Extract .klock, .rar (unrar), .7z, .zip, .gz/.tar.gz, .bz2, .xz, or .tar")
    p_unpack.add_argument("archive", type=Path, help="Input archive path")
    p_unpack.add_argument("-o", "--output", type=Path, default=Path("."), help="Destination directory")
    p_unpack.add_argument("--no-password", action="store_true", help="Do not prompt for a password")
    p_unpack.add_argument("--keyfile", type=Path, default=None)
    p_unpack.add_argument("--checksum", type=str, default=None, help="Expected SHA-256 hex or .sha256 file")

    p_unlock = sub.add_parser("unlock", help="Decrypt, verify checksums, and extract a .klock archive")
    p_unlock.add_argument("archive", type=Path)
    p_unlock.add_argument("-o", "--output", type=Path, default=Path("."))
    p_unlock.add_argument("--keyfile", type=Path, default=None)
    p_unlock.add_argument("--checksum", type=str, default=None)

    p_verify = sub.add_parser("verify", help="Verify .klock archive SHA-256 and encrypted file integrity")
    p_verify.add_argument("archive", type=Path)
    p_verify.add_argument("--keyfile", type=Path, default=None)
    p_verify.add_argument("--checksum", type=str, default=None)

    p_email = sub.add_parser("email", help="Compose an email with a compressed/locked archive attached")
    p_email.add_argument("archive", type=Path)
    p_email.add_argument("--to", type=str, default="")
    p_email.add_argument("--subject", type=str, default=None)
    p_email.add_argument("--no-checksum", action="store_true")

    p_list = sub.add_parser("list", help="Decrypt .klock manifest and list archive entries")
    p_list.add_argument("archive", type=Path)
    p_list.add_argument("--keyfile", type=Path, default=None)

    p_inspect = sub.add_parser("inspect", help="Inspect archive format, header, and SHA-256")
    p_inspect.add_argument("archive", type=Path)

    p_keygen = sub.add_parser("keygen", help="Generate a 64-byte CSPRNG keyfile")
    p_keygen.add_argument("output", type=Path)

    sub.add_parser("formats", help="Show detected Linux archive backends (rar, unrar, 7z, zip, python)")
    sub.add_parser("guide", help="Print a step-by-step how-to-use guide for CLI and GUI")
    sub.add_parser("install-context-menu", help="Install Ubuntu Files (Nautilus/Nemo) right-click menu scripts")

    args = parser.parse_args()

    try:
        if args.command == "formats":
            print(json.dumps(detect_available_backends(), indent=2))
        elif args.command == "guide":
            print(
                "KryptLock — Quick Usage Guide\n"
                "==============================\n"
                "1. Launch Desktop GUI:  kryptlock-gui  (or press Super and search KryptLock)\n"
                "2. Lock with .klock:    kryptlock lock secrets.klock ./files --algo lzma --write-checksum\n"
                "3. Pack .rar / .7z/.zip: kryptlock pack out.rar ./files --encrypt-headers\n"
                "   (use --no-password for unencrypted .rar, .7z, or .zip)\n"
                "4. Unpack any format:   kryptlock unpack archive.rar -o ./restored\n"
                "5. Verify .klock:       kryptlock verify secrets.klock --checksum secrets.klock.sha256\n"
                "6. Email archive:       kryptlock email secrets.klock --to colleague@example.com\n"
                "7. Check backends:      kryptlock formats\n"
                "8. Right-click menu:    kryptlock install-context-menu\n"
            )
        elif args.command == "install-context-menu":
            gui_cmd = shutil.which("kryptlock-gui") or (
                "/usr/bin/kryptlock-gui" if Path("/usr/bin/kryptlock-gui").is_file() else str(Path.home() / ".local/bin/kryptlock-gui")
            )
            lock_script = (
                "#!/usr/bin/env bash\n"
                "set -euo pipefail\n"
                'if [ "$#" -gt 0 ]; then\n'
                f'  exec "{gui_cmd}" --pack "$@"\n'
                'elif [ -n "${NAUTILUS_SCRIPT_SELECTED_FILE_PATHS:-}" ]; then\n'
                '  mapfile -t ITEMS <<< "$NAUTILUS_SCRIPT_SELECTED_FILE_PATHS"\n'
                f'  exec "{gui_cmd}" --pack "${{ITEMS[@]}}"\n'
                "else\n"
                f'  exec "{gui_cmd}"\n'
                "fi\n"
            )
            unpack_script = (
                "#!/usr/bin/env bash\n"
                "set -euo pipefail\n"
                'if [ "$#" -gt 0 ]; then\n'
                f'  exec "{gui_cmd}" "$1"\n'
                'elif [ -n "${NAUTILUS_SCRIPT_SELECTED_FILE_PATHS:-}" ]; then\n'
                '  FIRST="$(printf "%s" "$NAUTILUS_SCRIPT_SELECTED_FILE_PATHS" | head -n1)"\n'
                f'  exec "{gui_cmd}" "$FIRST"\n'
                "else\n"
                f'  exec "{gui_cmd}"\n'
                "fi\n"
            )
            targets = [Path.home() / ".local/share/nautilus/scripts"]
            for fm in ("nemo", "caja"):
                fm_base = Path.home() / ".local/share" / fm
                if fm_base.is_dir():
                    targets.append(fm_base / "scripts")
            installed = []
            for script_dir in targets:
                script_dir.mkdir(parents=True, exist_ok=True)
                for fname, content in (
                    ("Lock with KryptLock", lock_script),
                    ("Unpack with KryptLock", unpack_script),
                ):
                    out = script_dir / fname
                    out.write_text(content, encoding="utf-8")
                    os.chmod(out, 0o755)
                    installed.append(str(out))
            print("Installed right-click context menu scripts:")
            for item in installed:
                print(f"  - {item}")
            print("In Ubuntu Files, right-click any file or folder -> Scripts -> Lock with KryptLock")
        elif args.command == "inspect":
            info = inspect_any_archive(args.archive)
            print(json.dumps(info, indent=2))
        elif args.command == "keygen":
            args.output.write_bytes(secrets.token_bytes(64))
            os.chmod(args.output, 0o600)
            print(f"Generated 512-bit keyfile: {args.output} (chmod 600)")
        elif args.command == "email":
            launcher = open_email_composer(
                args.archive,
                recipient=args.to,
                subject=args.subject,
                include_checksum=not args.no_checksum,
            )
            print(f"Opened mail composer ({launcher}) with attachment: {args.archive}")
        elif args.command == "lock":
            pw = prompt_passphrase(confirm=True)
            res = encrypt_archive(
                args.inputs,
                args.output,
                pw,
                keyfile_path=args.keyfile,
                algorithm=args.algo,
                level=args.level,
                iterations=args.iterations,
                write_checksum_file=args.write_checksum,
            )
            print(f"Locked {res['entries']} file(s) [{res['algorithm']}] -> {res['output']} ({res['archive_size']} bytes)")
            print(f"Archive SHA-256: {res['archive_sha256']}")
            if res["checksum_file"]:
                print(f"Saved checksum:  {res['checksum_file']}")
            if args.email:
                launcher = open_email_composer(args.output, recipient=args.email)
                print(f"Opened mail composer ({launcher}) for {args.email}")
        elif args.command == "pack":
            fmt = format_from_output_name(args.output, args.format)
            if args.no_password or fmt in ("gz", "tar.gz", "bz2", "tar.bz2", "xz", "tar.xz", "tar"):
                pw = ""
            else:
                pw = prompt_passphrase(confirm=True, allow_empty=(fmt != "klock"))
            res = pack_archive(
                args.inputs,
                args.output,
                fmt=fmt,
                passphrase=pw or None,
                keyfile_path=args.keyfile,
                algorithm=args.algo,
                level=args.level,
                encrypt_headers=args.encrypt_headers,
                zip_crypto=args.zip_crypto,
                write_checksum_file=args.write_checksum,
            )
            print(f"Packed {res['entries']} file(s) [{res['format']}] -> {res['output']} ({res['archive_size']} bytes)")
            print(f"Archive SHA-256: {res['archive_sha256']}")
            if res["checksum_file"]:
                print(f"Saved checksum:  {res['checksum_file']}")
            if args.email:
                launcher = open_email_composer(args.output, recipient=args.email)
                print(f"Opened mail composer ({launcher}) for {args.email}")
        elif args.command == "unpack":
            fmt = detect_archive_format(args.archive)
            if args.no_password or fmt in ("gz", "tar.gz", "bz2", "tar.bz2", "xz", "tar.xz", "tar"):
                pw = ""
            else:
                pw = prompt_passphrase(confirm=False, allow_empty=(fmt != "klock"))
            results, integrity = unpack_archive(
                args.archive,
                args.output,
                passphrase=pw or None,
                keyfile_path=args.keyfile,
                expected_checksum=args.checksum,
            )
            print(f"Format:          {integrity.get('format', fmt)}")
            print(f"Archive SHA-256: {integrity['archive_sha256']}")
            for path, size, ok in results:
                status = "VERIFIED" if ok else "CHECKSUM MISMATCH"
                print(f"Extracted {path} ({size} B) [{status}]")
        elif args.command == "list":
            pw = prompt_passphrase(confirm=False)
            manifest, extracted, integrity = decrypt_archive_to_memory(args.archive, pw, args.keyfile)
            print(f"Created:         {manifest.get('createdAt', 'unknown')}")
            print(f"Archive SHA-256: {integrity['archive_sha256']}")
            for entry, _, ok in extracted:
                status = "VERIFIED" if ok else "CHECKSUM MISMATCH"
                print(f"  {entry['size']:>10} B  [{status}]  {entry['path']}")
            if not integrity["all_files_ok"]:
                print("ALERT: One or more entries failed integrity verification!", file=sys.stderr)
                sys.exit(2)
        elif args.command == "verify":
            pw = prompt_passphrase(confirm=False)
            _, extracted, integrity = decrypt_archive_to_memory(
                args.archive,
                pw,
                keyfile_path=args.keyfile,
                expected_checksum=args.checksum,
            )
            print(f"Archive SHA-256: {integrity['archive_sha256']} [VERIFIED]")
            for entry, _, ok in extracted:
                print(f"  {entry['path']}: {'VERIFIED' if ok else 'INTEGRITY FAILED'}")
            if not integrity["all_files_ok"]:
                print("ALERT: File integrity check failed!", file=sys.stderr)
                sys.exit(2)
            print(f"All {len(extracted)} file(s) passed SHA-256 integrity verification.")
        elif args.command == "unlock":
            pw = prompt_passphrase(confirm=False)
            results, integrity = unlock_archive(
                args.archive,
                args.output,
                pw,
                keyfile_path=args.keyfile,
                expected_checksum=args.checksum,
            )
            print(f"Archive SHA-256: {integrity['archive_sha256']}")
            for path, size, ok in results:
                status = "VERIFIED" if ok else "CHECKSUM MISMATCH"
                print(f"Extracted {path} ({size} B) [{status}]")
    except IntegrityError as exc:
        print(f"INTEGRITY ALERT: {exc}", file=sys.stderr)
        sys.exit(2)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
