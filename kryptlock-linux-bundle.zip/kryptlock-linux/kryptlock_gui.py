#!/usr/bin/env python3
"""
KryptLock Desktop GUI for Linux
Uses GTK4 + Libadwaita when available, with an automatic dark-themed Tkinter fallback.
Supports .klock, .rar (rar/unrar with & without password), .7z, .zip, .tar.gz/.gz, .tar.bz2, .tar.xz,
password strength feedback, SHA-256 integrity verification, and xdg-email attachment composing.
"""

import base64
import struct
import sys
import threading
import zlib
from pathlib import Path
from typing import List, Optional

from kryptlock import (
    DEFAULT_ITERATIONS,
    IntegrityError,
    detect_available_backends,
    evaluate_password_strength,
    inspect_any_archive,
    open_email_composer,
    pack_archive,
    unpack_archive,
)

FORMAT_OPTIONS = ["klock", "rar", "7z", "zip", "tar.gz", "tar.bz2", "tar.xz", "gz"]
ALGO_OPTIONS = ["deflate", "gzip", "bzip2", "lzma", "store"]

USAGE_HELP_TEXT = """KryptLock — How to Use the Native Desktop & CLI App

1. Pack & Lock (Compress + Encrypt)
   • Click 'Add Files' (or drag files/folders) to stage items for archiving.
   • Select an output format:
     - klock   : AES-256-GCM encrypted vault with PBKDF2 + SHA-256 integrity manifest (password required).
     - rar     : RAR archive via native 'rar' CLI (password optional; supports header encryption).
     - 7z      : 7-Zip archive via '7z' CLI (optional AES-256 password + encrypted filenames).
     - zip     : ZIP archive (optional password via 7z/zip, or unencrypted).
     - tar.gz / tar.bz2 / tar.xz / gz : Standard compressed Linux tarballs (no password).
   • For .klock archives, choose an inner compression codec (deflate, gzip, bzip2, lzma, store).
   • Enter and confirm your password (watch the strength indicator; leave blank for open .rar/.7z/.zip).
   • Click 'Create Archive' to save the archive alongside a .sha256 checksum file.

2. Email Compressed / Locked Archive
   • Enter a recipient email address (optional) and click 'Email Archive'.
   • KryptLock invokes xdg-email / Thunderbird with both the archive and .sha256 file attached.

3. Unpack & Verify (Extract + Integrity Check)
   • Open the 'Unpack & Verify' tab and select any .klock, .rar, .7z, .zip, .tar.gz, .gz, .bz2, or .xz file.
   • Optionally paste a SHA-256 hex digest or path to a .sha256 file to verify before extracting.
   • Enter the password if the archive is locked (leave blank for unencrypted archives) and pick a destination folder.
   • If tampering or corruption is detected, KryptLock halts with an INTEGRITY ALERT.

4. CLI Shortcuts (Terminal)
   • kryptlock formats                 Show detected rar / unrar / 7z / zip backends
   • kryptlock guide                   Print quick command-line examples
   • kryptlock pack out.7z ./folder    Create encrypted or open 7z archive
   • kryptlock unpack out.rar -o ./out Extract RAR archive (with or without password)
"""


def format_backend_status_text() -> str:
    info = detect_available_backends()
    missing = []
    if not info.get("klock_aes_gcm"):
        missing.append("python3-cryptography")
    if not info.get("7z"):
        missing.append("p7zip-full")
    if not info.get("rar_extract"):
        missing.append("unrar")
    if not info.get("rar_create"):
        missing.append("rar")
    lines = [
        "Detected Ubuntu / Linux Backends",
        "--------------------------------",
        f"KLOCK001 (AES-256-GCM) : {'Ready' if info.get('klock_aes_gcm') else 'Missing python3-cryptography'}",
        f"RAR Create (rar)       : {info.get('rar_create') or 'Not installed'}",
        f"RAR Extract (unrar/7z) : {info.get('rar_extract') or 'Not installed'}",
        f"7-Zip (7z / 7zz)       : {info.get('7z') or 'Not installed'}",
        f"ZIP / UnZip CLI        : {info.get('zip_cli') or 'Python stdlib'} / {info.get('unzip_cli') or 'Python stdlib'}",
        f"Stdlib Codecs          : {info.get('python_stdlib')}",
    ]
    if missing:
        lines.append("")
        lines.append("To install missing optional/system packages on Ubuntu:")
        lines.append(f"sudo apt update && sudo apt install -y {' '.join(missing)} xdg-utils")
    return "\n".join(lines)


def _find_krypt_png() -> Optional[Path]:
    candidates = [
        Path(__file__).with_name("krypt.png"),
        Path("/usr/share/kryptlock/krypt.png"),
        Path.home() / ".local/share/kryptlock/krypt.png",
        Path.cwd() / "krypt.png",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def _dim_png_to_b64(png_path: Path, opacity: float = 0.16) -> Optional[str]:
    try:
        raw = png_path.read_bytes()
        if raw[:8] != bytes.fromhex("89504e470d0a1a0a"):
            return None
        pos = 8
        ihdr = None
        idat_parts: List[bytes] = []
        while pos + 8 <= len(raw):
            length, ctype = struct.unpack(">I4s", raw[pos:pos + 8])
            data = raw[pos + 8:pos + 8 + length]
            pos += 12 + length
            if ctype == b"IHDR":
                ihdr = data
            elif ctype == b"IDAT":
                idat_parts.append(data)
            elif ctype == b"IEND":
                break
        if ihdr is None or not idat_parts:
            return None
        width, height, bit_depth, color_type, _comp, _flt, interlace = struct.unpack(">IIBBBBB", ihdr)
        if bit_depth != 8 or interlace != 0 or color_type not in (2, 6):
            return None
        bpp = 4 if color_type == 6 else 3
        stride = width * bpp
        decompressed = zlib.decompress(b"".join(idat_parts))
        prev = bytearray(stride)
        out_rows = bytearray()
        offset = 0
        for _y in range(height):
            ftype = decompressed[offset]
            offset += 1
            row = bytearray(decompressed[offset:offset + stride])
            offset += stride
            if ftype == 1:
                for i in range(bpp, stride):
                    row[i] = (row[i] + row[i - bpp]) & 0xFF
            elif ftype == 2:
                for i in range(stride):
                    row[i] = (row[i] + prev[i]) & 0xFF
            elif ftype == 3:
                for i in range(stride):
                    left = row[i - bpp] if i >= bpp else 0
                    row[i] = (row[i] + ((left + prev[i]) >> 1)) & 0xFF
            elif ftype == 4:
                for i in range(stride):
                    a = row[i - bpp] if i >= bpp else 0
                    b = prev[i]
                    c = prev[i - bpp] if i >= bpp else 0
                    p = a + b - c
                    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                    pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                    row[i] = (row[i] + pr) & 0xFF
            prev = row
            out_rows.append(0)
            if color_type == 6:
                for i in range(0, stride, 4):
                    out_rows.extend((row[i], row[i + 1], row[i + 2], int(row[i + 3] * opacity)))
            else:
                alpha = int(255 * opacity)
                for i in range(0, stride, 3):
                    out_rows.extend((row[i], row[i + 1], row[i + 2], alpha))

        def _chunk(tag: bytes, payload: bytes) -> bytes:
            return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)

        new_ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
        dimmed = (
            bytes.fromhex("89504e470d0a1a0a")
            + _chunk(b"IHDR", new_ihdr)
            + _chunk(b"IDAT", zlib.compress(bytes(out_rows), 6))
            + _chunk(b"IEND", b"")
        )
        return base64.b64encode(dimmed).decode("ascii")
    except Exception:
        return None


def launch_tkinter_gui(
    initial_file: Optional[Path] = None,
    staged_initial: Optional[List[Path]] = None,
) -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("KryptLock — Linux Multi-Format Archive & Lock Utility")
    root.geometry("900x700")
    root.configure(bg="#0B0F17")

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("TFrame", background="#0B0F17")
    style.configure("TLabel", background="#0B0F17", foreground="#E2E8F0", font=("Sans", 10))
    style.configure("Header.TLabel", background="#0B0F17", foreground="#F8FAFC", font=("Sans", 14, "bold"))
    style.configure("TNotebook", background="#0B0F17", borderwidth=0)
    style.configure("TNotebook.Tab", background="#141A24", foreground="#94A3B8", padding=[16, 8])
    style.map("TNotebook.Tab", background=[("selected", "#1E293B")], foreground=[("selected", "#F8FAFC")])

    watermark_photo = None
    png_path = _find_krypt_png()
    if png_path is not None:
        dim_b64 = _dim_png_to_b64(png_path, opacity=0.16)
        if dim_b64:
            try:
                watermark_photo = tk.PhotoImage(data=dim_b64).zoom(2, 2).subsample(3, 3)
            except Exception:
                watermark_photo = None
    root._krypt_watermark_photo = watermark_photo  # keep reference alive

    def create_watermarked_text_canvas(parent: tk.Misc, height_px: int = 210, initial_text: str = ""):
        container = tk.Frame(parent, bg="#141A24", highlightthickness=1, highlightbackground="#283244")
        canvas = tk.Canvas(container, bg="#141A24", highlightthickness=0, height=height_px)
        scroll = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        state = {"text": initial_text}

        def redraw(_event: object = None) -> None:
            canvas.delete("all")
            w = max(canvas.winfo_width(), 320)
            h = max(canvas.winfo_height(), height_px)
            y_top = canvas.canvasy(0)
            text_id = canvas.create_text(
                14,
                12,
                text=state["text"],
                anchor="nw",
                fill="#E2E8F0",
                font=("Monospace", 10),
                width=max(w - 32, 260),
            )
            bbox = canvas.bbox(text_id)
            content_h = (bbox[3] + 16) if bbox else h
            canvas.configure(scrollregion=(0, 0, w, max(h, content_h)))
            if watermark_photo is not None:
                wm_id = canvas.create_image(w // 2, int(y_top + h // 2), image=watermark_photo, anchor="center")
                canvas.tag_lower(wm_id)

        def on_scroll(event: tk.Event) -> None:
            delta = -1 if getattr(event, "delta", 0) > 0 or getattr(event, "num", 0) == 4 else 1
            canvas.yview_scroll(delta, "units")
            redraw()

        def set_text(new_text: str) -> None:
            state["text"] = new_text
            canvas.yview_moveto(0.0)
            redraw()

        canvas.bind("<Configure>", redraw)
        canvas.bind("<MouseWheel>", on_scroll)
        canvas.bind("<Button-4>", on_scroll)
        canvas.bind("<Button-5>", on_scroll)
        scroll.bind("<B1-Motion>", lambda _e: root.after_idle(redraw))
        return container, set_text

    def show_tk_dialog(title: str, body: str) -> None:
        win = tk.Toplevel(root)
        win.title(title)
        win.geometry("680x480")
        win.configure(bg="#0B0F17")
        box, _set = create_watermarked_text_canvas(win, height_px=390, initial_text=body)
        box.pack(fill="both", expand=True, padx=14, pady=(14, 8))
        tk.Button(win, text="Close", command=win.destroy, bg="#1E293B", fg="#F8FAFC", relief="flat", padx=16, pady=6).pack(pady=(0, 12))

    menubar = tk.Menu(root, bg="#111722", fg="#E2E8F0", activebackground="#1E293B", activeforeground="#F8FAFC")
    help_menu = tk.Menu(menubar, tearoff=0, bg="#111722", fg="#E2E8F0", activebackground="#1E293B", activeforeground="#F8FAFC")
    help_menu.add_command(label="How to Use KryptLock", command=lambda: show_tk_dialog("How to Use KryptLock", USAGE_HELP_TEXT))
    help_menu.add_command(label="Check Installed Backends", command=lambda: show_tk_dialog("Detected Backends", format_backend_status_text()))
    help_menu.add_separator()
    help_menu.add_command(
        label="About KryptLock",
        command=lambda: messagebox.showinfo(
            "About KryptLock",
            "KryptLock 1.0.0\nLinux Multi-Format Compression & AES-256-GCM Archive Tool\nSupports .klock, .rar, .7z, .zip, .tar.gz, .tar.bz2, and .tar.xz.",
        ),
    )
    menubar.add_cascade(label="Help", menu=help_menu)
    root.config(menu=menubar)

    header = ttk.Frame(root, padding=16)
    header.pack(fill="x")
    ttk.Label(header, text="KryptLock", style="Header.TLabel").pack(side="left")
    tk.Button(
        header,
        text="Help & Guide",
        command=lambda: show_tk_dialog("How to Use KryptLock", USAGE_HELP_TEXT),
        bg="#1E293B",
        fg="#F8FAFC",
        relief="flat",
        padx=10,
        pady=4,
    ).pack(side="right", padx=(10, 0))
    ttk.Label(
        header,
        text="KLOCK · RAR / UnRAR · 7z · ZIP · Gzip / Bzip2 / XZ · SHA-256",
        foreground="#94A3B8",
    ).pack(side="right")

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True, padx=16, pady=(0, 16))

    # --- Pack & Lock Tab ---
    lock_tab = ttk.Frame(notebook, padding=16)
    notebook.add(lock_tab, text="Pack & Lock")

    staged_paths: List[Path] = list(staged_initial or [])
    list_container = tk.Frame(lock_tab, bg="#141A24", highlightthickness=1, highlightbackground="#283244")
    list_container.pack(fill="both", expand=True, pady=(0, 10))

    list_canvas = tk.Canvas(list_container, bg="#141A24", highlightthickness=0, height=185)
    list_scroll = ttk.Scrollbar(list_container, orient="vertical", command=list_canvas.yview)
    list_canvas.configure(yscrollcommand=list_scroll.set)
    list_scroll.pack(side="right", fill="y")
    list_canvas.pack(side="left", fill="both", expand=True)

    selected_index: Optional[int] = None

    def redraw_staged_list(_event: object = None) -> None:
        list_canvas.delete("all")
        w = max(list_canvas.winfo_width(), 320)
        h = max(list_canvas.winfo_height(), 185)
        row_h = 28
        total_h = max(h, len(staged_paths) * row_h + 16)
        list_canvas.configure(scrollregion=(0, 0, w, total_h))

        # Keep dimmed krypt.png centered inside visible area behind the file rows
        y_top = list_canvas.canvasy(0)
        if watermark_photo is not None:
            list_canvas.create_image(w // 2, int(y_top + h // 2), image=watermark_photo, anchor="center", tags=("wm",))

        if not staged_paths:
            list_canvas.create_text(
                w // 2,
                int(y_top + h - 22),
                text="Use 'Add Files' or 'Add Folder' to stage items here",
                fill="#64748B",
                font=("Sans", 9),
            )
            return

        for idx, p in enumerate(staged_paths):
            y1 = 8 + idx * row_h
            y2 = y1 + row_h - 2
            label = f"[DIR] {p}" if p.is_dir() else str(p)
            if selected_index == idx:
                list_canvas.create_rectangle(8, y1, w - 8, y2, fill="#064E3B", outline="#10B981", width=1)
                fg_color = "#ECFDF5"
            else:
                fg_color = "#F1F5F9"
            list_canvas.create_text(16, (y1 + y2) // 2, text=label, anchor="w", fill=fg_color, font=("Monospace", 9))

        list_canvas.tag_lower("wm")

    def on_list_click(event: tk.Event) -> None:
        nonlocal selected_index
        y = list_canvas.canvasy(event.y)
        idx = int((y - 8) // 28)
        selected_index = idx if 0 <= idx < len(staged_paths) else None
        redraw_staged_list()

    def on_list_scroll(event: tk.Event) -> None:
        delta = -1 if getattr(event, "delta", 0) > 0 or getattr(event, "num", 0) == 4 else 1
        list_canvas.yview_scroll(delta, "units")
        redraw_staged_list()

    list_canvas.bind("<Configure>", redraw_staged_list)
    list_canvas.bind("<Button-1>", on_list_click)
    list_canvas.bind("<MouseWheel>", on_list_scroll)
    list_canvas.bind("<Button-4>", on_list_scroll)
    list_canvas.bind("<Button-5>", on_list_scroll)
    list_scroll.bind("<B1-Motion>", lambda _e: root.after_idle(redraw_staged_list))

    def add_files() -> None:
        files = filedialog.askopenfilenames(title="Select files to pack")
        for f in files:
            p = Path(f)
            if p not in staged_paths:
                staged_paths.append(p)
        redraw_staged_list()

    def add_folder() -> None:
        folder = filedialog.askdirectory(title="Select folder to pack")
        if folder:
            p = Path(folder)
            if p not in staged_paths:
                staged_paths.append(p)
        redraw_staged_list()

    def clear_staged() -> None:
        nonlocal selected_index
        staged_paths.clear()
        selected_index = None
        redraw_staged_list()

    btn_row = ttk.Frame(lock_tab)
    btn_row.pack(fill="x", pady=(0, 10))
    tk.Button(btn_row, text="Add Files", command=add_files, bg="#1E293B", fg="#F8FAFC", relief="flat", padx=12, pady=6).pack(side="left", padx=(0, 8))
    tk.Button(btn_row, text="Add Folder", command=add_folder, bg="#1E293B", fg="#F8FAFC", relief="flat", padx=12, pady=6).pack(side="left", padx=(0, 8))
    tk.Button(btn_row, text="Clear List", command=clear_staged, bg="#1E293B", fg="#94A3B8", relief="flat", padx=12, pady=6).pack(side="left")

    fmt_row = ttk.Frame(lock_tab)
    fmt_row.pack(fill="x", pady=(0, 10))
    ttk.Label(fmt_row, text="Archive Format:").pack(side="left", padx=(0, 8))
    fmt_var = tk.StringVar(value="klock")
    ttk.Combobox(fmt_row, textvariable=fmt_var, values=FORMAT_OPTIONS, state="readonly", width=10).pack(side="left", padx=(0, 16))
    ttk.Label(fmt_row, text=".klock Codec:").pack(side="left", padx=(0, 8))
    algo_var = tk.StringVar(value="deflate")
    ttk.Combobox(fmt_row, textvariable=algo_var, values=ALGO_OPTIONS, state="readonly", width=10).pack(side="left", padx=(0, 16))
    ttk.Label(fmt_row, text="Level (1-9):").pack(side="left", padx=(0, 8))
    level_var = tk.IntVar(value=6)
    ttk.Spinbox(fmt_row, from_=1, to=9, textvariable=level_var, width=5).pack(side="left")

    pw_frame = ttk.Frame(lock_tab)
    pw_frame.pack(fill="x", pady=(0, 6))
    ttk.Label(pw_frame, text="Password (optional):", width=18).pack(side="left")
    lock_pw_var = tk.StringVar()
    tk.Entry(pw_frame, textvariable=lock_pw_var, show="*", bg="#141A24", fg="#F8FAFC", insertbackground="#F8FAFC", relief="flat").pack(side="left", fill="x", expand=True)

    pw2_frame = ttk.Frame(lock_tab)
    pw2_frame.pack(fill="x", pady=(0, 6))
    ttk.Label(pw2_frame, text="Confirm Password:", width=18).pack(side="left")
    lock_pw2_var = tk.StringVar()
    tk.Entry(pw2_frame, textvariable=lock_pw2_var, show="*", bg="#141A24", fg="#F8FAFC", insertbackground="#F8FAFC", relief="flat").pack(side="left", fill="x", expand=True)

    strength_label = tk.Label(
        lock_tab,
        text="Strength: Empty (0 bits) · Leave blank for unencrypted .rar/.7z/.zip/.tar.gz",
        bg="#0B0F17",
        fg="#94A3B8",
        anchor="w",
        font=("Sans", 9),
    )
    strength_label.pack(fill="x", pady=(0, 8))

    def on_pw_change(*_args: object) -> None:
        pw = lock_pw_var.get()
        if not pw:
            strength_label.config(text="Strength: Empty · Leave blank for unencrypted .rar/.7z/.zip/.tar.*", fg="#94A3B8")
            return
        s = evaluate_password_strength(pw)
        colors = {0: "#94A3B8", 1: "#F87171", 2: "#FBBF24", 3: "#34D399", 4: "#10B981"}
        hint = f" · {s['hints'][0]}" if s["hints"] else ""
        strength_label.config(text=f"Password Strength: {s['label']} ({s['bits']} bits){hint}", fg=colors[s["score"]])

    lock_pw_var.trace_add("write", on_pw_change)

    opts_row = ttk.Frame(lock_tab)
    opts_row.pack(fill="x", pady=(0, 8))
    encrypt_headers_var = tk.BooleanVar(value=True)
    tk.Checkbutton(
        opts_row,
        text="Encrypt filenames/headers (.rar -hp / .7z -mhe)",
        variable=encrypt_headers_var,
        bg="#0B0F17",
        fg="#CBD5E1",
        selectcolor="#141A24",
        activebackground="#0B0F17",
        activeforeground="#F8FAFC",
    ).pack(side="left", padx=(0, 16))
    write_sha_var = tk.BooleanVar(value=True)
    tk.Checkbutton(
        opts_row,
        text="Write .sha256 sidecar",
        variable=write_sha_var,
        bg="#0B0F17",
        fg="#CBD5E1",
        selectcolor="#141A24",
        activebackground="#0B0F17",
        activeforeground="#F8FAFC",
    ).pack(side="left")

    last_locked_archive: Optional[Path] = None

    email_row = ttk.Frame(lock_tab)
    email_row.pack(fill="x", pady=(0, 8))
    ttk.Label(email_row, text="Email Recipient:", width=18).pack(side="left")
    email_to_var = tk.StringVar()
    tk.Entry(email_row, textvariable=email_to_var, bg="#141A24", fg="#F8FAFC", insertbackground="#F8FAFC", relief="flat").pack(side="left", fill="x", expand=True)

    def do_email_locked() -> None:
        nonlocal last_locked_archive
        target = last_locked_archive
        if target is None or not target.is_file():
            picked = filedialog.askopenfilename(title="Select archive to email")
            if not picked:
                return
            target = Path(picked)
        try:
            launcher = open_email_composer(target, recipient=email_to_var.get().strip())
            messagebox.showinfo("KryptLock Email", f"Opened Linux mail client ({launcher}) with {target.name} attached.")
        except Exception as err:
            messagebox.showerror("Email Launch Failed", str(err))

    def do_pack() -> None:
        nonlocal last_locked_archive
        if not staged_paths:
            messagebox.showwarning("KryptLock", "Add at least one file or folder first.")
            return
        fmt = fmt_var.get()
        pw = lock_pw_var.get()
        if fmt == "klock" and not pw:
            messagebox.showwarning("KryptLock", "Enter a password for .klock AES-256-GCM encryption.")
            return
        if pw and pw != lock_pw2_var.get():
            messagebox.showerror("KryptLock", "Passwords do not match.")
            return
        out = filedialog.asksaveasfilename(
            title=f"Save .{fmt} archive",
            defaultextension=f".{fmt}",
            filetypes=[("Archive", f"*.{fmt}"), ("All files", "*.*")],
        )
        if not out:
            return

        def worker() -> None:
            nonlocal last_locked_archive
            try:
                out_path = Path(out)
                res = pack_archive(
                    staged_paths,
                    out_path,
                    fmt=fmt,
                    passphrase=pw or None,
                    algorithm=algo_var.get(),
                    level=level_var.get(),
                    iterations=DEFAULT_ITERATIONS,
                    encrypt_headers=encrypt_headers_var.get(),
                    write_checksum_file=write_sha_var.get(),
                )
                last_locked_archive = out_path
                msg = (
                    f"Created {out_path.name} ({res['format']}, {res['entries']} file(s)).\n"
                    f"Archive SHA-256:\n{res['archive_sha256']}"
                )
                root.after(0, lambda: messagebox.showinfo("Archive Created & Checksummed", msg))
            except Exception as err:
                root.after(0, lambda: messagebox.showerror("Pack Failed", str(err)))

        threading.Thread(target=worker, daemon=True).start()

    lock_actions = ttk.Frame(lock_tab)
    lock_actions.pack(fill="x")
    tk.Button(lock_actions, text="Email Archive", command=do_email_locked, bg="#1E293B", fg="#F8FAFC", relief="flat", padx=14, pady=8).pack(side="left")
    tk.Button(lock_actions, text="Create Archive", command=do_pack, bg="#10B981", fg="#052E16", font=("Sans", 10, "bold"), relief="flat", padx=16, pady=8).pack(side="right")

    # --- Unlock / Extract Tab ---
    unlock_tab = ttk.Frame(notebook, padding=16)
    notebook.add(unlock_tab, text="Unpack & Verify")

    archive_var = tk.StringVar(value=str(initial_file) if initial_file else "")
    row1 = ttk.Frame(unlock_tab)
    row1.pack(fill="x", pady=(0, 8))
    ttk.Label(row1, text="Archive File:", width=18).pack(side="left")
    tk.Entry(row1, textvariable=archive_var, bg="#141A24", fg="#F8FAFC", insertbackground="#F8FAFC", relief="flat").pack(side="left", fill="x", expand=True, padx=(0, 8))

    def browse_archive() -> None:
        path = filedialog.askopenfilename(
            title="Open archive (.klock, .rar, .7z, .zip, .gz, .bz2, .xz, .tar)",
            filetypes=[
                ("Supported Archives", "*.klock *.rar *.7z *.zip *.gz *.tgz *.bz2 *.tbz2 *.xz *.txz *.tar"),
                ("All files", "*.*"),
            ],
        )
        if path:
            archive_var.set(path)

    tk.Button(row1, text="Browse", command=browse_archive, bg="#1E293B", fg="#F8FAFC", relief="flat", padx=12, pady=6).pack(side="right")

    row_sha = ttk.Frame(unlock_tab)
    row_sha.pack(fill="x", pady=(0, 8))
    ttk.Label(row_sha, text="Expected SHA-256:", width=18).pack(side="left")
    expected_sha_var = tk.StringVar()
    tk.Entry(row_sha, textvariable=expected_sha_var, bg="#141A24", fg="#F8FAFC", insertbackground="#F8FAFC", relief="flat").pack(side="left", fill="x", expand=True)

    row2 = ttk.Frame(unlock_tab)
    row2.pack(fill="x", pady=(0, 10))
    ttk.Label(row2, text="Password (if locked):", width=18).pack(side="left")
    unlock_pw_var = tk.StringVar()
    tk.Entry(row2, textvariable=unlock_pw_var, show="*", bg="#141A24", fg="#F8FAFC", insertbackground="#F8FAFC", relief="flat").pack(side="left", fill="x", expand=True)

    output_frame, set_output_text = create_watermarked_text_canvas(
        unlock_tab,
        height_px=220,
        initial_text="Select any .klock, .rar, .7z, .zip, .tar.gz, .gz, .bz2, or .xz archive and click Inspect or Extract.",
    )
    output_frame.pack(fill="both", expand=True, pady=(0, 12))

    def do_inspect() -> None:
        p = Path(archive_var.get().strip())
        if not p.is_file():
            messagebox.showwarning("KryptLock", "Select a valid archive file first.")
            return
        try:
            info = inspect_any_archive(p)
            lines = [
                f"Format:          {info['format']}",
                f"Magic:           {info['magic']}",
                f"Archive SHA-256: {info['archive_sha256']}",
                f"Total Size:      {info['total_bytes']:,} bytes",
            ]
            if "iterations" in info:
                lines.append(f"PBKDF2 Rounds:   {info['iterations']:,}")
            set_output_text("\n".join(lines))
        except Exception as err:
            messagebox.showerror("Inspection Error", str(err))

    def do_extract() -> None:
        p = Path(archive_var.get().strip())
        pw = unlock_pw_var.get()
        if not p.is_file():
            messagebox.showwarning("KryptLock", "Select a valid archive file first.")
            return
        dest = filedialog.askdirectory(title="Choose extraction folder")
        if not dest:
            return
        expected_sha = expected_sha_var.get().strip() or None

        def worker() -> None:
            try:
                results, integrity = unpack_archive(p, Path(dest), passphrase=pw or None, expected_checksum=expected_sha)
                lines = [
                    f"Format:          {integrity.get('format', 'archive')}",
                    f"Archive SHA-256: {integrity['archive_sha256']} [VERIFIED]",
                    "",
                ]
                lines.extend(
                    f"{name} ({size} B) — {'VERIFIED' if ok else 'CHECKSUM MISMATCH'}"
                    for name, size, ok in results
                )
                summary = "\n".join(lines)
                root.after(0, lambda: set_output_text(summary))
            except IntegrityError as err:
                root.after(0, lambda: messagebox.showerror("INTEGRITY CHECK FAILED", str(err)))
            except Exception as err:
                root.after(0, lambda: messagebox.showerror("Extract Failed", str(err)))

        threading.Thread(target=worker, daemon=True).start()

    act_row = ttk.Frame(unlock_tab)
    act_row.pack(fill="x")
    tk.Button(act_row, text="Inspect Format & SHA-256", command=do_inspect, bg="#1E293B", fg="#F8FAFC", relief="flat", padx=14, pady=8).pack(side="left")
    tk.Button(act_row, text="Unpack / Unlock & Extract", command=do_extract, bg="#10B981", fg="#052E16", font=("Sans", 10, "bold"), relief="flat", padx=16, pady=8).pack(side="right")

    # --- Help & Guide Tab ---
    help_tab = ttk.Frame(notebook, padding=16)
    notebook.add(help_tab, text="Help & Guide")
    help_frame, set_help_text = create_watermarked_text_canvas(
        help_tab,
        height_px=360,
        initial_text=f"{USAGE_HELP_TEXT}\n{format_backend_status_text()}",
    )
    help_frame.pack(fill="both", expand=True, pady=(0, 10))

    def refresh_help_backends() -> None:
        set_help_text(f"{USAGE_HELP_TEXT}\n{format_backend_status_text()}")

    tk.Button(help_tab, text="Refresh Detected Backends", command=refresh_help_backends, bg="#1E293B", fg="#F8FAFC", relief="flat", padx=14, pady=8).pack(side="left")

    if staged_paths:
        redraw_staged_list()
    if initial_file:
        notebook.select(unlock_tab)
        do_inspect()

    root.mainloop()


def _parse_gui_args(argv: List[str]):
    archive_exts = {
        ".klock", ".rar", ".7z", ".zip", ".tgz", ".gz",
        ".tbz2", ".bz2", ".txz", ".xz", ".tar",
    }
    force_pack = False
    paths: List[Path] = []
    for raw in argv:
        if raw == "--pack":
            force_pack = True
            continue
        p = Path(raw).expanduser()
        if p.exists():
            paths.append(p)
    if force_pack or len(paths) > 1:
        return None, paths
    if len(paths) == 1:
        p = paths[0]
        if p.is_file() and (
            p.suffix.lower() in archive_exts
            or any(p.name.lower().endswith(ext) for ext in (".tar.gz", ".tar.bz2", ".tar.xz"))
        ):
            return p, []
        return None, [p]
    return None, []


def main() -> None:
    initial, staged_initial = _parse_gui_args(sys.argv[1:])
    try:
        import gi
        gi.require_version("Gtk", "4.0")
        gi.require_version("Adw", "1")
        from gi.repository import Adw, Gdk, Gio, Gtk

        css = Gtk.CssProvider()
        css.load_from_data(
            b"""
            .krypt-filelist-frame {
                background-color: #141A24;
                border: 1px solid #283244;
                border-radius: 10px;
            }
            list.krypt-filelist,
            list.krypt-filelist > row {
                background-color: transparent;
                color: #E2E8F0;
            }
            list.krypt-filelist > row label {
                color: #E2E8F0;
            }
            list.krypt-filelist > row .subtitle {
                color: #94A3B8;
            }
            list.krypt-filelist > row:hover {
                background-color: rgba(16, 185, 129, 0.12);
            }
            list.krypt-filelist > row:selected {
                background-color: rgba(16, 185, 129, 0.22);
            }
            textview.krypt-watermarked-text,
            textview.krypt-watermarked-text text {
                background-color: transparent;
                color: #E2E8F0;
            }
            scrolledwindow.krypt-watermarked-scroll {
                background-color: transparent;
            }
            """
        )
        display = Gdk.Display.get_default()
        if display is not None:
            Gtk.StyleContext.add_provider_for_display(
                display, css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )

        class KryptLockWindow(Adw.ApplicationWindow):
            def __init__(self, app: Adw.Application) -> None:
                super().__init__(application=app, title="KryptLock", default_width=820, default_height=640)
                self.staged_files: List[Path] = list(staged_initial)

                toolbar = Adw.ToolbarView()
                header = Adw.HeaderBar()
                switcher = Adw.ViewSwitcher()
                stack = Adw.ViewStack()
                switcher.set_stack(stack)
                header.set_title_widget(switcher)

                help_menu_model = Gio.Menu()
                help_menu_model.append("How to Use KryptLock", "win.help-usage")
                help_menu_model.append("Check Installed Backends", "win.help-backends")
                help_menu_model.append("About KryptLock", "win.about")

                help_btn = Gtk.MenuButton(label="Help", menu_model=help_menu_model)
                help_btn.set_tooltip_text("How to Use & Diagnostics (F1)")
                header.pack_end(help_btn)

                for action_name, cb in (
                    ("help-usage", lambda _a, _p: self._show_text_dialog("How to Use KryptLock", USAGE_HELP_TEXT)),
                    ("help-backends", lambda _a, _p: self._show_text_dialog("Detected Ubuntu / Linux Backends", format_backend_status_text())),
                    (
                        "about",
                        lambda _a, _p: self._show_text_dialog(
                            "About KryptLock",
                            "KryptLock 1.0.0\n"
                            "Native Ubuntu & Linux Multi-Format Compression and Encryption Utility\n\n"
                            "Formats: .klock (AES-256-GCM), .rar / UnRAR, .7z, .zip, .tar.gz, .tar.bz2, .tar.xz\n"
                            "Integrates SHA-256 integrity verification and xdg-email attachment composing.",
                        ),
                    ),
                ):
                    act = Gio.SimpleAction.new(action_name, None)
                    act.connect("activate", cb)
                    self.add_action(act)

                toolbar.add_top_bar(header)

                # Pack & Lock page
                lock_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
                lock_box.set_margin_top(20)
                lock_box.set_margin_bottom(20)
                lock_box.set_margin_start(20)
                lock_box.set_margin_end(20)

                self.list_box = Gtk.ListBox()
                self.list_box.add_css_class("krypt-filelist")
                for staged_item in self.staged_files:
                    row = Adw.ActionRow(
                        title=f"[DIR] {staged_item.name}" if staged_item.is_dir() else staged_item.name,
                        subtitle=str(staged_item.parent),
                    )
                    self.list_box.append(row)
                lock_box.append(self._wrap_with_watermark(self.list_box, min_height=185))

                controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                add_btn = Gtk.Button(label="Add Files")
                add_btn.connect("clicked", self.on_add_files)
                clear_btn = Gtk.Button(label="Clear")
                clear_btn.connect("clicked", self.on_clear)
                self.fmt_dropdown = Gtk.DropDown.new_from_strings(FORMAT_OPTIONS)
                self.algo_dropdown = Gtk.DropDown.new_from_strings(ALGO_OPTIONS)
                controls.append(add_btn)
                controls.append(clear_btn)
                controls.append(self.fmt_dropdown)
                controls.append(self.algo_dropdown)
                lock_box.append(controls)

                self.lock_pw = Gtk.PasswordEntry(placeholder_text="Password (optional for .rar/.7z/.zip)", show_peek_icon=True)
                self.lock_pw.connect("changed", self.on_password_changed)
                lock_box.append(self.lock_pw)

                self.lock_pw_confirm = Gtk.PasswordEntry(placeholder_text="Confirm password", show_peek_icon=True)
                lock_box.append(self.lock_pw_confirm)

                self.strength_label = Gtk.Label(label="Password Strength: Empty · Leave blank for unencrypted .rar/.7z/.zip", xalign=0)
                lock_box.append(self.strength_label)

                self.last_locked_path: Optional[Path] = None

                self.email_entry = Gtk.Entry(placeholder_text="Recipient email (optional, e.g. alice@example.com)")
                lock_box.append(self.email_entry)

                self.lock_status = Gtk.Label(label="", wrap=True, xalign=0)
                lock_box.append(self.lock_status)

                action_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                lock_btn = Gtk.Button(label="Create Archive")
                lock_btn.add_css_class("suggested-action")
                lock_btn.connect("clicked", self.on_pack_archive)
                email_btn = Gtk.Button(label="Email Archive")
                email_btn.connect("clicked", self.on_email_locked)
                action_box.append(lock_btn)
                action_box.append(email_btn)
                lock_box.append(action_box)

                stack.add_titled_with_icon(lock_box, "lock", "Pack & Lock", "changes-prevent-symbolic")

                # Unpack page
                unlock_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
                unlock_box.set_margin_top(20)
                unlock_box.set_margin_bottom(20)
                unlock_box.set_margin_start(20)
                unlock_box.set_margin_end(20)

                archive_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                self.archive_entry = Gtk.Entry(placeholder_text="Path to .klock, .rar, .7z, .zip, .tar.gz, .gz, .bz2, or .xz archive")
                self.archive_entry.set_hexpand(True)
                if initial:
                    self.archive_entry.set_text(str(initial))
                browse_btn = Gtk.Button(label="Browse")
                browse_btn.connect("clicked", self.on_browse_archive)
                archive_row.append(self.archive_entry)
                archive_row.append(browse_btn)
                unlock_box.append(archive_row)

                self.checksum_entry = Gtk.Entry(placeholder_text="Optional expected SHA-256 hex or .sha256 file")
                unlock_box.append(self.checksum_entry)

                self.unlock_pw = Gtk.PasswordEntry(placeholder_text="Password (leave blank if archive is unencrypted)", show_peek_icon=True)
                unlock_box.append(self.unlock_pw)

                self.unpack_view = Gtk.TextView(editable=False, cursor_visible=False, monospace=True)
                self.unpack_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
                self.unpack_view.set_top_margin(12)
                self.unpack_view.set_bottom_margin(12)
                self.unpack_view.set_left_margin(14)
                self.unpack_view.set_right_margin(14)
                self.unpack_view.add_css_class("krypt-watermarked-text")
                self.unpack_view.get_buffer().set_text(
                    "Select any .klock, .rar, .7z, .zip, .tar.gz, .gz, .bz2, or .xz archive and click Inspect or Extract."
                )
                unlock_box.append(self._wrap_with_watermark(self.unpack_view, min_height=200))

                self.status_label = Gtk.Label(label="Select any archive (.klock, .rar, .7z, .zip, .gz, .bz2, .xz) to unpack.", wrap=True, xalign=0)
                unlock_box.append(self.status_label)

                unpack_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                inspect_btn = Gtk.Button(label="Inspect Format & SHA-256")
                inspect_btn.connect("clicked", self.on_inspect_archive)
                unlock_btn = Gtk.Button(label="Unpack / Unlock & Extract")
                unlock_btn.add_css_class("suggested-action")
                unlock_btn.connect("clicked", self.on_unpack_archive)
                unpack_actions.append(inspect_btn)
                unpack_actions.append(unlock_btn)
                unlock_box.append(unpack_actions)

                stack.add_titled_with_icon(unlock_box, "unlock", "Unpack & Verify", "changes-allow-symbolic")

                # Help & Guide page
                help_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
                help_box.set_margin_top(20)
                help_box.set_margin_bottom(20)
                help_box.set_margin_start(20)
                help_box.set_margin_end(20)

                self.help_view = Gtk.TextView(editable=False, cursor_visible=False, monospace=True)
                self.help_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
                self.help_view.set_top_margin(12)
                self.help_view.set_bottom_margin(12)
                self.help_view.set_left_margin(14)
                self.help_view.set_right_margin(14)
                self.help_view.add_css_class("krypt-watermarked-text")
                self.help_view.get_buffer().set_text(f"{USAGE_HELP_TEXT}\n{format_backend_status_text()}")
                help_box.append(self._wrap_with_watermark(self.help_view, min_height=280))

                refresh_btn = Gtk.Button(label="Refresh Detected Backends")
                refresh_btn.connect("clicked", self.on_refresh_help_backends)
                help_box.append(refresh_btn)

                stack.add_titled_with_icon(help_box, "help", "Help", "help-about-symbolic")

                if initial:
                    stack.set_visible_child_name("unlock")
                    self.on_inspect_archive(None)

                toolbar.set_content(stack)
                self.set_content(toolbar)

            def _wrap_with_watermark(self, child_widget: Gtk.Widget, min_height: int = 185) -> Gtk.Box:
                frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
                frame.add_css_class("krypt-filelist-frame")
                frame.set_vexpand(True)
                frame.set_size_request(-1, min_height)

                overlay = Gtk.Overlay()
                overlay.set_vexpand(True)
                overlay.set_overflow(Gtk.Overflow.HIDDEN)

                png_path = _find_krypt_png()
                if png_path is not None:
                    watermark = Gtk.Image.new_from_file(str(png_path))
                    watermark.set_pixel_size(190)
                    watermark.set_opacity(0.16)
                    watermark.set_halign(Gtk.Align.CENTER)
                    watermark.set_valign(Gtk.Align.CENTER)
                    watermark.set_can_target(False)
                    overlay.set_child(watermark)
                else:
                    overlay.set_child(Gtk.Box())

                scrolled = Gtk.ScrolledWindow(vexpand=True)
                scrolled.add_css_class("krypt-watermarked-scroll")
                scrolled.set_child(child_widget)
                overlay.add_overlay(scrolled)
                frame.append(overlay)
                return frame

            def on_refresh_help_backends(self, _btn: Gtk.Button) -> None:
                self.help_view.get_buffer().set_text(f"{USAGE_HELP_TEXT}\n{format_backend_status_text()}")

            def _show_text_dialog(self, title: str, body: str) -> None:
                dlg = Gtk.Window(title=title, transient_for=self, modal=True, default_width=680, default_height=480)
                box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
                box.set_margin_top(16)
                box.set_margin_bottom(16)
                box.set_margin_start(16)
                box.set_margin_end(16)

                tv = Gtk.TextView(editable=False, cursor_visible=False, monospace=True)
                tv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
                tv.set_top_margin(12)
                tv.set_bottom_margin(12)
                tv.set_left_margin(14)
                tv.set_right_margin(14)
                tv.add_css_class("krypt-watermarked-text")
                tv.get_buffer().set_text(body)
                box.append(self._wrap_with_watermark(tv, min_height=340))

                close_btn = Gtk.Button(label="Close")
                close_btn.connect("clicked", lambda _b: dlg.close())
                box.append(close_btn)

                dlg.set_child(box)
                dlg.present()

            def on_password_changed(self, _entry: Gtk.PasswordEntry) -> None:
                pw = self.lock_pw.get_text()
                if not pw:
                    self.strength_label.set_text("Password Strength: Empty · Leave blank for unencrypted .rar/.7z/.zip")
                    return
                s = evaluate_password_strength(pw)
                hint = f" — {s['hints'][0]}" if s["hints"] else ""
                self.strength_label.set_text(f"Password Strength: {s['label']} ({s['bits']} bits){hint}")

            def on_add_files(self, _btn: Gtk.Button) -> None:
                dialog = Gtk.FileDialog()
                dialog.open_multiple(self, None, self._on_files_picked)

            def _on_files_picked(self, dialog: Gtk.FileDialog, res: Gio.AsyncResult) -> None:
                try:
                    files = dialog.open_multiple_finish(res)
                    for i in range(files.get_n_items()):
                        f = files.get_item(i)
                        p = Path(f.get_path())
                        if p not in self.staged_files:
                            self.staged_files.append(p)
                            row = Adw.ActionRow(title=p.name, subtitle=str(p.parent))
                            self.list_box.append(row)
                except Exception:
                    pass

            def on_clear(self, _btn: Gtk.Button) -> None:
                self.staged_files.clear()
                while child := self.list_box.get_first_child():
                    self.list_box.remove(child)

            def on_pack_archive(self, _btn: Gtk.Button) -> None:
                fmt = FORMAT_OPTIONS[self.fmt_dropdown.get_selected()]
                pw = self.lock_pw.get_text()
                pw2 = self.lock_pw_confirm.get_text()
                if not self.staged_files:
                    self.lock_status.set_text("Stage files first.")
                    return
                if fmt == "klock" and not pw:
                    self.lock_status.set_text("Enter a password for .klock AES-256-GCM encryption.")
                    return
                if pw and pw != pw2:
                    self.lock_status.set_text("Error: Passwords do not match.")
                    return
                algo = ALGO_OPTIONS[self.algo_dropdown.get_selected()]
                dialog = Gtk.FileDialog(initial_name=f"archive.{fmt}")
                dialog.save(self, None, lambda d, r: self._finish_save(d, r, fmt, pw, algo))

            def _finish_save(self, dialog: Gtk.FileDialog, res: Gio.AsyncResult, fmt: str, pw: str, algo: str) -> None:
                try:
                    f = dialog.save_finish(res)
                    out_path = Path(f.get_path())
                    info = pack_archive(
                        self.staged_files,
                        out_path,
                        fmt=fmt,
                        passphrase=pw or None,
                        algorithm=algo,
                        write_checksum_file=True,
                    )
                    self.last_locked_path = out_path
                    self.lock_status.set_text(f"Created {out_path.name} ({fmt}). SHA-256: {info['archive_sha256']}")
                except Exception as exc:
                    self.lock_status.set_text(f"Pack error: {exc}")

            def on_email_locked(self, _btn: Gtk.Button) -> None:
                if self.last_locked_path and self.last_locked_path.is_file():
                    self._launch_email(self.last_locked_path)
                    return
                dialog = Gtk.FileDialog()
                dialog.open(self, None, self._on_email_file_picked)

            def _on_email_file_picked(self, dialog: Gtk.FileDialog, res: Gio.AsyncResult) -> None:
                try:
                    f = dialog.open_finish(res)
                    self._launch_email(Path(f.get_path()))
                except Exception:
                    pass

            def _launch_email(self, archive_path: Path) -> None:
                try:
                    launcher = open_email_composer(archive_path, recipient=self.email_entry.get_text().strip())
                    self.lock_status.set_text(f"Opened mail client ({launcher}) with {archive_path.name} attached.")
                except Exception as exc:
                    self.lock_status.set_text(f"Email error: {exc}")

            def on_browse_archive(self, _btn: Gtk.Button) -> None:
                dialog = Gtk.FileDialog()
                dialog.open(self, None, self._on_archive_picked)

            def _on_archive_picked(self, dialog: Gtk.FileDialog, res: Gio.AsyncResult) -> None:
                try:
                    f = dialog.open_finish(res)
                    self.archive_entry.set_text(f.get_path())
                    self.on_inspect_archive(None)
                except Exception:
                    pass

            def on_inspect_archive(self, _btn: Optional[Gtk.Button]) -> None:
                archive = Path(self.archive_entry.get_text().strip())
                if not archive.is_file():
                    self.status_label.set_text("Provide a valid archive file path.")
                    return
                try:
                    info = inspect_any_archive(archive)
                    lines = [
                        f"Format:          {info['format']}",
                        f"Magic:           {info['magic']}",
                        f"Archive SHA-256: {info['archive_sha256']}",
                        f"Total Size:      {info['total_bytes']:,} bytes",
                    ]
                    if "iterations" in info:
                        lines.append(f"PBKDF2 Rounds:   {info['iterations']:,}")
                    self.unpack_view.get_buffer().set_text("\n".join(lines))
                    self.status_label.set_text(f"Inspected {archive.name} ({info['format']}).")
                except Exception as exc:
                    self.status_label.set_text(f"Inspection error: {exc}")

            def on_unpack_archive(self, _btn: Gtk.Button) -> None:
                archive = Path(self.archive_entry.get_text().strip())
                pw = self.unlock_pw.get_text()
                if not archive.is_file():
                    self.status_label.set_text("Provide a valid archive file path.")
                    return
                expected_sha = self.checksum_entry.get_text().strip() or None
                dialog = Gtk.FileDialog()
                dialog.select_folder(self, None, lambda d, r: self._finish_extract(d, r, archive, pw, expected_sha))

            def _finish_extract(self, dialog: Gtk.FileDialog, res: Gio.AsyncResult, archive: Path, pw: str, expected_sha: Optional[str]) -> None:
                try:
                    folder = dialog.select_folder_finish(res)
                    extracted, integrity = unpack_archive(archive, Path(folder.get_path()), passphrase=pw or None, expected_checksum=expected_sha)
                    lines = [
                        f"Format:          {integrity.get('format', 'archive')}",
                        f"Archive SHA-256: {integrity['archive_sha256']} [VERIFIED]",
                        "",
                    ]
                    lines.extend(
                        f"{name} ({size} B) — {'VERIFIED' if ok else 'CHECKSUM MISMATCH'}"
                        for name, size, ok in extracted
                    )
                    self.unpack_view.get_buffer().set_text("\n".join(lines))
                    self.status_label.set_text(
                        f"Extracted {len(extracted)} file(s) [{integrity.get('format')}]. Archive SHA-256: {integrity['archive_sha256']}"
                    )
                except IntegrityError as exc:
                    self.status_label.set_text(f"INTEGRITY ALERT: {exc}")
                except Exception as exc:
                    self.status_label.set_text(f"Extract error: {exc}")

        class KryptLockApp(Adw.Application):
            def __init__(self) -> None:
                super().__init__(application_id="org.kryptlock.ArchiveTool")

            def do_activate(self) -> None:
                self.set_accels_for_action("win.help-usage", ["F1"])
                win = KryptLockWindow(self)
                win.present()

        app = KryptLockApp()
        app.run(None)
    except Exception:
        launch_tkinter_gui(initial, staged_initial)


if __name__ == "__main__":
    main()
