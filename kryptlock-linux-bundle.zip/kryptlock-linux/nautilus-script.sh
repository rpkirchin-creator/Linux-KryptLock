#!/usr/bin/env bash
# Right-click "Scripts -> Lock with KryptLock" for GNOME Files (Nautilus) / Nemo
set -euo pipefail

GUI_BIN="kryptlock-gui"
if ! command -v kryptlock-gui >/dev/null 2>&1; then
  if [ -x "/usr/bin/kryptlock-gui" ]; then
    GUI_BIN="/usr/bin/kryptlock-gui"
  else
    GUI_BIN="${HOME}/.local/bin/kryptlock-gui"
  fi
fi

if [ "$#" -gt 0 ]; then
  exec "${GUI_BIN}" --pack "$@"
elif [ -n "${NAUTILUS_SCRIPT_SELECTED_FILE_PATHS:-}" ]; then
  mapfile -t ITEMS <<< "${NAUTILUS_SCRIPT_SELECTED_FILE_PATHS}"
  exec "${GUI_BIN}" --pack "${ITEMS[@]}"
else
  exec "${GUI_BIN}"
fi
